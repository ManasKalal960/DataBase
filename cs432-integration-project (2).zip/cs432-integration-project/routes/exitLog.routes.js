const express = require('express');
const router = express.Router();
const controller = require('../controllers/exitLog.controller');
const { authenticate, authorize } = require('../middleware/auth.middleware');

router.post('/', authenticate, authorize('security'), controller.logExit);
router.get('/', authenticate, controller.getExitLogs);

module.exports = router;
