const express = require('express');
const router = express.Router();
const controller = require('../controllers/securityStaff.controller');
const { authenticate, authorize } = require('../middleware/auth.middleware');

router.post('/', authenticate, authorize('admin'), controller.createSecurityStaff);
router.get('/', authenticate, controller.getAllSecurityStaff);

module.exports = router;
