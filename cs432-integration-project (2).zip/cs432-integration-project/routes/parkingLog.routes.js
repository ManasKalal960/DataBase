const express = require('express');
const router = express.Router();
const controller = require('../controllers/parkingLog.controller');
const { authenticate, authorize } = require('../middleware/auth.middleware');

// Log Parking Entry - Security Staff
router.post('/entry', 
  authenticate, 
  authorize('security'), 
  controller.logEntry
);

// Log Parking Exit - Security Staff
router.patch('/exit/:id', 
  authenticate, 
  authorize('security'), 
  controller.logExit
);

// Get Parking History - Authenticated Users
router.get('/', 
  authenticate, 
  controller.getParkingHistory
);

module.exports = router;
