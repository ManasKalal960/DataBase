const express = require('express');
const router = express.Router();
const controller = require('../controllers/entryLog.controller');
const { authenticate, authorize } = require('../middleware/auth.middleware');

router.post('/', authenticate, authorize('security'), controller.logEntry);
router.get('/', authenticate, controller.getEntryLogs);

module.exports = router;
