const express = require('express');
const router = express.Router();
const controller = require('../controllers/gate.controller');
const { authenticate, authorize } = require('../middleware/auth.middleware');

router.get('/', authenticate, controller.listAllGates);
router.patch('/:id/status', authenticate, authorize('security'), controller.changeGateStatus);

module.exports = router;
