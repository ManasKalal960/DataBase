const express = require('express');
const router = express.Router();
const controller = require('../controllers/accessPermission.controller');
const { authenticate, authorize } = require('../middleware/auth.middleware');

router.post('/', authenticate, authorize('admin'), controller.createPermission);
router.get('/:role', authenticate, controller.getPermissions);

module.exports = router;
