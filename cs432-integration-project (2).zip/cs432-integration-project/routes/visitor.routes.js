const express = require('express');
const router = express.Router();
const controller = require('../controllers/visitor.controller');
const { authenticate, authorize } = require('../middleware/auth.middleware');

router.post('/', authenticate, authorize('security'), controller.registerVisitor);
router.get('/:id', authenticate, controller.getVisitorDetails);
router.patch('/:id/exit', authenticate, authorize('security'), controller.recordExit);

module.exports = router;
