const express = require('express');
const router = express.Router();

// Import routes
const membersRoutes = require('./members.routes');
const authRoutes = require('./auth.routes');
const collageMemberRoutes = require('./collageMember.routes');
const vehicleRoutes = require('./vehicles.routes');
const portfolioRoutes = require('./portfolio.routes');
const visitorRoutes = require('./visitor.routes');
const gateRoutes = require('./gate.routes');
const entryLogRoutes = require('./entryLog.routes');
const exitLogRoutes = require('./exitLog.routes');
const securityStaffRoutes = require('./securityStaff.routes');
const accessPermissionRoutes = require('./accessPermission.routes');
const alertRoutes = require('./alert.routes');
const parkingLogRoutes = require('./parkingLog.routes');

// Register routes
router.use('/members', membersRoutes);
router.use('/auth', authRoutes);
router.use('/collage-members', collageMemberRoutes);
router.use('/vehicles', vehicleRoutes);
router.use('/portfolio', portfolioRoutes);
router.use('/visitors', visitorRoutes);
router.use('/gates', gateRoutes);
router.use('/entry-logs', entryLogRoutes);
router.use('/exit-logs', exitLogRoutes);
router.use('/security-staff', securityStaffRoutes);
router.use('/access-permissions', accessPermissionRoutes);
router.use('/alerts', alertRoutes);
router.use('/parking', parkingLogRoutes);

module.exports = router;
