const express = require('express');
const router = express.Router();
const portfolioController = require('../controllers/portfolio.controller');
const { authenticate } = require('../middleware/auth.middleware');


router.post('/', authenticate, portfolioController.createPortfolio);
router.get('/:id', authenticate, portfolioController.createPortfolio);


module.exports = router;
