const express = require('express');
const router = express.Router();
const controller = require('../controllers/alert.controller');
const { authenticate, authorize } = require('../middleware/auth.middleware');

// Create Alert - Security Staff and Admin
router.post('/', 
  authenticate, 
  authorize('security', 'admin'), 
  controller.createAlert
);

// Get All Alerts - Authenticated Users
router.get('/', 
  authenticate, 
  controller.getAllAlerts
);

// Resolve Alert - Security Staff and Admin
router.patch('/:id/resolve', 
  authenticate, 
  authorize('security', 'admin'), 
  controller.resolveAlert
);

// Delete Alert - Admin Only
router.delete('/:id', 
  authenticate, 
  authorize('admin'), 
  controller.deleteAlert
);

module.exports = router;
