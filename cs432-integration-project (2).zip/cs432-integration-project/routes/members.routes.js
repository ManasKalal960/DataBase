const express = require('express');
const router = express.Router();
const membersController = require('../controllers/members.controller');
const { authenticate } = require('../middleware/auth.middleware');
const { authorize } = require('../middleware/role.middleware');

// Only admins can create or delete members
router.post('/', 
  authenticate,
  authorize('admin'),
  membersController.createMember
);

router.delete('/:id', 
  authenticate,
  authorize('admin'),
  membersController.deleteMember
);

module.exports = router;
