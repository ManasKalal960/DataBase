const express = require('express');
const router = express.Router();
const controller = require('../controllers/collageMember.controller');
const { authenticate, authorize } = require('../middleware/auth.middleware');

router.post('/', authenticate, authorize('admin'), controller.createMember);
router.get('/:id', authenticate, controller.getMember);
router.put('/:id', authenticate, authorize('admin'), controller.updateMember);
router.delete('/:id', authenticate, authorize('admin'), controller.deleteMember);

module.exports = router;
