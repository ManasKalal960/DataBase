const express = require('express');
const router = express.Router();
const controller = require('../controllers/vehicles.controller');
const { authenticate } = require('../middleware/auth.middleware');

router.post('/', authenticate, controller.createVehicle);
router.get('/:id', authenticate, controller.getVehicle);
router.delete('/:id', authenticate, controller.removeVehicle);

module.exports = router;
