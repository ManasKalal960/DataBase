const { projectPool, cimsPool } = require('../config/db.config');
const logger = require('../utils/logger');

exports.createPortfolio = async (req, res) => {
  const { member_id, bio, skills } = req.body;

  if (!member_id) {
    return res.status(400).json({ error: "Member ID is required" });
  }

  try {
    // Convert skills array to JSON string if it exists, otherwise use null
    const skillsJSON = skills ? JSON.stringify(skills) : null;
    
    // Ensure all parameters are explicitly null rather than undefined
    const [result] = await projectPool.execute(
      `INSERT INTO Portfolio (member_id, bio, skills)
       VALUES (?, ?, ?)`,
      [
        member_id,
        bio || null, // Convert undefined to null
        skillsJSON  // Already handled above
      ]
    );

    logger.info(`Portfolio created for member ${member_id}`);
    res.status(201).json({ 
      message: "Portfolio created successfully", 
      portfolioId: result.insertId 
    });
  } catch (error) {
    logger.error(`Portfolio creation failed: ${error.message}`);
    res.status(500).json({ error: "Failed to create portfolio" });
  }
};
