const {
    addVehicle,
    getVehicleById,
    deleteVehicle
  } = require('../models/project.models');
  const logger = require('../utils/logger');
  
  exports.createVehicle = async (req, res) => {
    try {
      const vehicleId = await addVehicle(req.body);
      logger.info(`Vehicle added: ID ${vehicleId}`);
      res.status(201).json({ message: "Vehicle created", vehicleId });
    } catch (error) {
      logger.error(`Vehicle creation failed: ${error.message}`);
      res.status(500).json({ error: "Failed to add vehicle" });
    }
  };
  
  exports.getVehicle = async (req, res) => {
    try {
      const vehicle = await getVehicleById(req.params.id);
      vehicle ? res.json(vehicle) : res.status(404).json({ error: "Vehicle not found" });
    } catch (error) {
      res.status(500).json({ error: "Failed to retrieve vehicle" });
    }
  };
  
  exports.removeVehicle = async (req, res) => {
    try {
      await deleteVehicle(req.params.id);
      logger.info(`Vehicle ${req.params.id} deleted`);
      res.json({ message: "Vehicle deleted" });
    } catch (error) {
      logger.error(`Vehicle deletion failed: ${error.message}`);
      res.status(500).json({ error: "Failed to delete vehicle" });
    }
  };
  