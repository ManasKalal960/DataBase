const { 
    createVisitor,
    getVisitorById,
    logVisitorExit
  } = require('../models/project.models');
  const logger = require('../utils/logger');
  
  exports.registerVisitor = async (req, res) => {
    const { name, purpose } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: "Visitor name is required" });
    }
  
    try {
      const visitorId = await createVisitor({ name, purpose });
      logger.info(`New visitor registered: ${name}`);
      res.status(201).json({ 
        message: "Visitor registered successfully",
        visitorId 
      });
    } catch (error) {
      logger.error(`Visitor registration failed: ${error.message}`);
      res.status(500).json({ error: "Failed to register visitor" });
    }
  };
  
  exports.getVisitorDetails = async (req, res) => {
    try {
      const visitor = await getVisitorById(req.params.id);
      visitor ? res.json(visitor) : res.status(404).json({ error: "Visitor not found" });
    } catch (error) {
      logger.error(`Visitor lookup failed: ${error.message}`);
      res.status(500).json({ error: "Failed to retrieve visitor details" });
    }
  };
  
  exports.recordExit = async (req, res) => {
    try {
      await logVisitorExit(req.params.id);
      logger.info(`Exit recorded for visitor ${req.params.id}`);
      res.json({ message: "Exit time updated successfully" });
    } catch (error) {
      logger.error(`Exit recording failed: ${error.message}`);
      res.status(500).json({ error: "Failed to record exit time" });
    }
  };
  