const { addSecurityStaff, getSecurityStaff } = require('../models/project.models');
const logger = require('../utils/logger');

exports.createSecurityStaff = async (req, res) => {
  const { name, role, contact_number } = req.body;
  
  if (!name || !role) {
    return res.status(400).json({ error: "Name and role are required" });
  }

  try {
    const staffId = await addSecurityStaff({ name, role, contact_number });
    logger.info(`Security staff added: ${name}`);
    res.status(201).json({ message: "Staff created", staffId });
  } catch (error) {
    logger.error(`Staff creation failed: ${error.message}`);
    res.status(500).json({ error: "Failed to add staff" });
  }
};

exports.getAllSecurityStaff = async (req, res) => {
  try {
    const staff = await getSecurityStaff();
    res.json(staff);
  } catch (error) {
    logger.error(`Staff retrieval failed: ${error.message}`);
    res.status(500).json({ error: "Failed to retrieve staff" });
  }
};
