const { createMember, deleteMember } = require('../models/cims.models');
const logger = require('../utils/logger');

exports.createMember = async (req, res) => {
  const { memberid, name, email, role, dob, password } = req.body;

  console.log("Create Member Request:", req.body);

  if (!memberid || !password || !name || !email || !role) {
    return res.status(400).json({ error: "Missing required fields" });
  }

  try {
    // First create the member entry
    const [memberResult] = await connection.execute(
      `INSERT INTO members (ID, UserName, emailID, DoB)
       VALUES (?, ?, ?, ?)`,
      [memberid, name, email, dob]
    );
    
    // Then create login entry with the role
    await connection.execute(
      `INSERT INTO Login (MemberID, Password, Role)
       VALUES (?, ?, ?)`,
      [memberid, password, role]
    );
    
    console.log("Member created successfully with ID:", memberid);
    
    logger.info(`New member created: ${name} (ID: ${memberid})`);
    res.status(201).json({ message: "Member created successfully", memberId: memberid });
  } catch (error) {
    console.error("Error creating member:", error);
    logger.error(`Error creating member: ${error.message}`);
    res.status(500).json({ error: "Failed to create member" });
  }
};

exports.deleteMember = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await deleteMember(id);
    if (result === 'removed_group') {
      logger.info(`Member ${id} removed from group only`);
      res.json({ message: "Member removed from group only" });
    } else if (result === 'deleted') {
      logger.info(`Member ${id} deleted completely`);
      res.json({ message: "Member deleted completely" });
    } else {
      res.status(404).json({ error: "Member not found" });
    }
  } catch (error) {
    logger.error(`Error deleting member: ${error.message}`);
    res.status(500).json({ error: "Failed to delete member" });
  }
};
