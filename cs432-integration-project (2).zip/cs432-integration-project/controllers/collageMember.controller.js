const {
    createCollageMember,
    getCollageMemberById,
    updateCollageMember,
    deleteCollageMember
  } = require('../models/project.models');
  const logger = require('../utils/logger');
  
  exports.createMember = async (req, res) => {
    try {
      const memberId = await createCollageMember(req.body);
      logger.info(`Collage member created: ID ${memberId}`);
      res.status(201).json({ message: "Member created", memberId });
    } catch (error) {
      logger.error(`Member creation failed: ${error.message}`);
      res.status(500).json({ error: "Failed to create member" });
    }
  };
  
  exports.getMember = async (req, res) => {
    try {
      const member = await getCollageMemberById(req.params.id);
      member ? res.json(member) : res.status(404).json({ error: "Member not found" });
    } catch (error) {
      res.status(500).json({ error: "Failed to retrieve member" });
    }
  };
  
  exports.updateMember = async (req, res) => {
    try {
      await updateCollageMember(req.params.id, req.body);
      logger.info(`Member ${req.params.id} updated`);
      res.json({ message: "Member updated" });
    } catch (error) {
      logger.error(`Member update failed: ${error.message}`);
      res.status(500).json({ error: "Failed to update member" });
    }
  };
  
  exports.deleteMember = async (req, res) => {
    try {
      await deleteCollageMember(req.params.id);
      logger.info(`Member ${req.params.id} deleted`);
      res.json({ message: "Member deleted" });
    } catch (error) {
      logger.error(`Member deletion failed: ${error.message}`);
      res.status(500).json({ error: "Failed to delete member" });
    }
  };
  