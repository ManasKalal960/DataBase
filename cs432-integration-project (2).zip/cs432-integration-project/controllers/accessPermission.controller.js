const { createAccessPermission, getPermissionsByRole } = require('../models/project.models');
const logger = require('../utils/logger');

exports.createPermission = async (req, res) => {
  const { role, resource, action } = req.body;

  if (!role || !resource || !action) {
    return res.status(400).json({ error: "All fields are required" });
  }

  try {
    const permissionId = await createAccessPermission({ role, resource, action });
    logger.info(`Permission created for ${role}`);
    res.status(201).json({ message: "Permission created", permissionId });
  } catch (error) {
    logger.error(`Permission creation failed: ${error.message}`);
    res.status(500).json({ error: "Failed to create permission" });
  }
};

exports.getPermissions = async (req, res) => {
  try {
    const permissions = await getPermissionsByRole(req.params.role);
    res.json(permissions);
  } catch (error) {
    logger.error(`Permission retrieval failed: ${error.message}`);
    res.status(500).json({ error: "Failed to retrieve permissions" });
  }
};
