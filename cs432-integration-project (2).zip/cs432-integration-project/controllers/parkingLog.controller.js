const { 
    createParkingEntry,
    updateParkingExit,
    getParkingLogs
  } = require('../models/project.models');
  const logger = require('../utils/logger');
  
  exports.logEntry = async (req, res) => {
    const { vehicle_id } = req.body;
    
    if (!vehicle_id) {
      return res.status(400).json({ error: "Vehicle ID is required" });
    }
  
    try {
      const logId = await createParkingEntry(vehicle_id);
      logger.info(`Parking entry logged for vehicle ${vehicle_id} by ${req.user.userid}`);
      res.status(201).json({ 
        message: "Parking entry recorded",
        logId 
      });
    } catch (error) {
      logger.error(`Parking entry logging failed: ${error.message}`);
      res.status(500).json({ error: "Failed to log parking entry" });
    }
  };
  
  exports.logExit = async (req, res) => {
    const { id } = req.params;
    
    try {
      await updateParkingExit(id);
      logger.info(`Parking exit logged for log ID ${id} by ${req.user.userid}`);
      res.json({ message: "Parking exit recorded" });
    } catch (error) {
      logger.error(`Parking exit logging failed: ${error.message}`);
      res.status(500).json({ error: "Failed to log parking exit" });
    }
  };
  
  exports.getParkingHistory = async (req, res) => {
    try {
      const logs = await getParkingLogs();
      res.json(logs);
    } catch (error) {
      logger.error(`Parking log retrieval failed: ${error.message}`);
      res.status(500).json({ error: "Failed to retrieve parking logs" });
    }
  };
  