const { 
    getAllGates,
    updateGateStatus
  } = require('../models/project.models');
  const logger = require('../utils/logger');
  
  exports.listAllGates = async (req, res) => {
    try {
      const gates = await getAllGates();
      res.json(gates);
    } catch (error) {
      logger.error(`Gate listing failed: ${error.message}`);
      res.status(500).json({ error: "Failed to retrieve gates" });
    }
  };
  
  exports.changeGateStatus = async (req, res) => {
    const { status } = req.body;
    const { id } = req.params;
  
    if (!['Open', 'Closed'].includes(status)) {
      return res.status(400).json({ error: "Invalid gate status" });
    }
  
    try {
      await updateGateStatus(id, status);
      logger.info(`Gate ${id} status changed to ${status}`);
      res.json({ message: "Gate status updated successfully" });
    } catch (error) {
      logger.error(`Gate status update failed: ${error.message}`);
      res.status(500).json({ error: "Failed to update gate status" });
    }
  };
  