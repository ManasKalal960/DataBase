const { 
    createAlert,
    getAlerts,
    updateAlertStatus,
    deleteAlert
  } = require('../models/project.models');
  const logger = require('../utils/logger');
  
  exports.createAlert = async (req, res) => {
    const { description, severity } = req.body;
    
    if (!description) {
      return res.status(400).json({ error: "Description is required" });
    }
  
    try {
      const alertId = await createAlert({ description, severity });
      logger.info(`New alert created by ${req.user.userid}: ${description}`);
      res.status(201).json({ 
        message: "Alert created successfully",
        alertId 
      });
    } catch (error) {
      logger.error(`Alert creation failed: ${error.message}`);
      res.status(500).json({ error: "Failed to create alert" });
    }
  };
  
  exports.getAllAlerts = async (req, res) => {
    try {
      const alerts = await getAlerts(req.query.limit || 50);
      res.json(alerts);
    } catch (error) {
      logger.error(`Alert retrieval failed: ${error.message}`);
      res.status(500).json({ error: "Failed to retrieve alerts" });
    }
  };
  
  exports.resolveAlert = async (req, res) => {
    const { id } = req.params;
    
    try {
      await updateAlertStatus(id);
      logger.info(`Alert ${id} resolved by ${req.user.userid}`);
      res.json({ message: "Alert resolved successfully" });
    } catch (error) {
      logger.error(`Alert resolution failed: ${error.message}`);
      res.status(500).json({ error: "Failed to resolve alert" });
    }
  };
  
  exports.deleteAlert = async (req, res) => {
    const { id } = req.params;
    
    try {
      await deleteAlert(id);
      logger.info(`Alert ${id} deleted by ${req.user.userid}`);
      res.json({ message: "Alert deleted successfully" });
    } catch (error) {
      logger.error(`Alert deletion failed: ${error.message}`);
      res.status(500).json({ error: "Failed to delete alert" });
    }
  };
  