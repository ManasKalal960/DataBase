const jwt = require('jsonwebtoken');
const { cimsPool } = require('../config/db.config');
const logger = require('../utils/logger');

exports.login = async (req, res) => {
  // Accept various input formats for flexibility
  const userid = req.body.userid || req.body.username || req.body.user;
  const password = req.body.password || req.body.pass;

  if (!userid || !password) {
    return res.status(400).json({ error: "Missing required fields" });
  }

  try {
    // Query the database for the user
    const [rows] = await cimsPool.execute(
      `SELECT MemberID, Role FROM Login 
       WHERE LOWER(MemberID) = LOWER(?) AND Password = ?`,
      [userid, password]
    );

    if (rows.length === 0) {
      logger.warn(`Failed login attempt for user: ${userid}`);
      return res.status(401).json({ error: "Invalid credentials" });
    }

    // Create JWT token with minimal payload
    const token = jwt.sign(
      { 
        userid: rows[0].MemberID, 
        role: rows[0].Role 
      },
      process.env.JWT_SECRET,
      { expiresIn: '2h' }
    );

    // Set token as cookie (for browser clients)
    res.cookie('session_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      path: '/',
      sameSite: 'lax'
    });

    // Log successful login
    logger.info(`User ${userid} logged in successfully`);
    
    // Return token in response body (for non-browser clients)
    res.json({ 
      message: "Login successful", 
      token,
      userId: rows[0].MemberID,
      role: rows[0].Role
    });
  } catch (error) {
    console.error("Database error during login:", error);
    logger.error(`Login error: ${error.message}`);
    res.status(500).json({ error: "Server error" });
  }
};
