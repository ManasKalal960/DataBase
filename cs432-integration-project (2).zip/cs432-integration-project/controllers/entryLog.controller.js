const { 
    createEntryLog,
    getRecentEntries
  } = require('../models/project.models');
  const logger = require('../utils/logger');
  
  exports.logEntry = async (req, res) => {
    const { visitor_id, gate_id } = req.body;
  
    if (!visitor_id || !gate_id) {
      return res.status(400).json({ 
        error: "Both visitor ID and gate ID are required" 
      });
    }
  
    try {
      const entryId = await createEntryLog(visitor_id, gate_id);
      logger.info(`New entry logged: Visitor ${visitor_id} at Gate ${gate_id}`);
      res.status(201).json({ 
        message: "Entry logged successfully",
        entryId
      });
    } catch (error) {
      logger.error(`Entry logging failed: ${error.message}`);
      res.status(500).json({ error: "Failed to log entry" });
    }
  };
  
  exports.getEntryLogs = async (req, res) => {
    try {
      const entries = await getRecentEntries();
      res.json(entries);
    } catch (error) {
      logger.error(`Entry log retrieval failed: ${error.message}`);
      res.status(500).json({ error: "Failed to retrieve entry logs" });
    }
  };
  