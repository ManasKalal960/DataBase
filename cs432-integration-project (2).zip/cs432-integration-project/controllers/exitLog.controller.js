const { createExitLog, getExitLogs } = require('../models/project.models');
const logger = require('../utils/logger');

exports.logExit = async (req, res) => {
  const { visitor_id, gate_id } = req.body;

  if (!visitor_id || !gate_id) {
    return res.status(400).json({ error: "Visitor ID and Gate ID required" });
  }

  try {
    const exitId = await createExitLog(visitor_id, gate_id);
    logger.info(`Exit logged for visitor ${visitor_id} at gate ${gate_id}`);
    res.status(201).json({ message: "Exit recorded", exitId });
  } catch (error) {
    logger.error(`Exit logging failed: ${error.message}`);
    res.status(500).json({ error: "Failed to log exit" });
  }
};

exports.getExitLogs = async (req, res) => {
  try {
    const exits = await getExitLogs();
    res.json(exits);
  } catch (error) {
    logger.error(`Exit log retrieval failed: ${error.message}`);
    res.status(500).json({ error: "Failed to retrieve exit logs" });
  }
};
