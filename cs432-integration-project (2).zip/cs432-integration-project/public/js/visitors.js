document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const addVisitorBtn = document.getElementById('add-visitor-btn');
    const visitorForm = document.getElementById('visitor-form');
    const visitorModal = document.getElementById('visitor-modal');
    const closeModal = visitorModal.querySelector('.close-modal');
    const cancelBtn = document.getElementById('cancel-visitor');
    const searchInput = document.getElementById('visitor-search');
    const searchBtn = document.getElementById('visitor-search-btn');
    
    // Event listeners
    if (addVisitorBtn) {
        addVisitorBtn.addEventListener('click', function() {
            showVisitorModal();
        });
    }
    
    if (closeModal) {
        closeModal.addEventListener('click', function() {
            visitorModal.style.display = 'none';
        });
    }
    
    if (cancelBtn) {
        cancelBtn.addEventListener('click', function() {
            visitorModal.style.display = 'none';
        });
    }
    
    if (visitorForm) {
        visitorForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveVisitor();
        });
    }
    
    if (searchBtn) {
        searchBtn.addEventListener('click', function() {
            searchVisitors(searchInput.value);
        });
    }
    
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchVisitors(this.value);
            }
        });
    }
});

// Load visitors
function loadVisitors() {
    const token = localStorage.getItem('token');
    const tableBody = document.getElementById('visitors-table-body');
    
    tableBody.innerHTML = '<tr><td colspan="6" class="text-center">Loading...</td></tr>';
    
    fetch('/api/visitors', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to fetch visitors');
        }
        return response.json();
    })
    .then(data => {
        if (data.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="6" class="text-center">No visitors found</td></tr>';
            return;
        }
        
        tableBody.innerHTML = '';
        data.forEach(visitor => {
            const entryTime = new Date(visitor.entry_time).toLocaleString();
            const exitTime = visitor.exit_time ? new Date(visitor.exit_time).toLocaleString() : 'Not Exited';
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${visitor.visitor_id}</td>
                <td>${visitor.name}</td>
                <td>${visitor.purpose}</td>
                <td>${entryTime}</td>
                <td>${exitTime}</td>
                <td>
                    ${visitor.exit_time ? '' : `
                        <button class="btn record-exit-btn" data-id="${visitor.visitor_id}">
                            <i class="fas fa-sign-out-alt"></i> Record Exit
                        </button>
                    `}
                    <button class="btn delete-btn" data-id="${visitor.visitor_id}">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </td>
            `;
            tableBody.appendChild(row);
        });
        
        // Add event listeners to action buttons
        document.querySelectorAll('.record-exit-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                recordVisitorExit(this.getAttribute('data-id'));
            });
        });
        
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                deleteVisitor(this.getAttribute('data-id'));
            });
        });
    })
    .catch(error => {
        console.error('Error loading visitors:', error);
        tableBody.innerHTML = '<tr><td colspan="6" class="text-center">Error loading visitors</td></tr>';
        showToast('Failed to load visitors', 'error');
    });
}

// Show visitor modal for adding
function showVisitorModal() {
    document.getElementById('visitor-modal-title').textContent = 'Add Visitor';
    document.getElementById('visitor-form').reset();
    document.getElementById('visitor-id').value = '';
    document.getElementById('visitor-modal').style.display = 'block';
}

// Save visitor
function saveVisitor() {
    const token = localStorage.getItem('token');
    
    const visitorData = {
        name: document.getElementById('visitor-name').value,
        purpose: document.getElementById('visitor-purpose').value
    };
    
    fetch('/api/visitors', {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(visitorData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to save visitor');
        }
        return response.json();
    })
    .then(data => {
        document.getElementById('visitor-modal').style.display = 'none';
        showToast('Visitor added successfully', 'success');
        loadVisitors();
    })
    .catch(error => {
        console.error('Error saving visitor:', error);
        showToast('Failed to add visitor', 'error');
    });
}

// Record visitor exit
function recordVisitorExit(visitorId) {
    const token = localStorage.getItem('token');
    
    fetch(`/api/visitors/${visitorId}/exit`, {
        method: 'PATCH',
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to record exit');
        }
        return response.json();
    })
    .then(data => {
        showToast('Visitor exit recorded successfully', 'success');
        loadVisitors();
    })
    .catch(error => {
        console.error('Error recording exit:', error);
        showToast('Failed to record exit', 'error');
    });
}

// Delete visitor
function deleteVisitor(visitorId) {
    if (!confirm('Are you sure you want to delete this visitor?')) {
        return;
    }
    
    const token = localStorage.getItem('token');
    
    fetch(`/api/visitors/${visitorId}`, {
        method: 'DELETE',
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to delete visitor');
        }
        return response.json();
    })
    .then(data => {
        showToast('Visitor deleted successfully', 'success');
        loadVisitors();
    })
    .catch(error => {
        console.error('Error deleting visitor:', error);
        showToast('Failed to delete visitor', 'error');
    });
}

// Search visitors
function searchVisitors(query) {
    if (!query.trim()) {
        loadVisitors();
        return;
    }
    
    const token = localStorage.getItem('token');
    const tableBody = document.getElementById('visitors-table-body');
    
    tableBody.innerHTML = '<tr><td colspan="6" class="text-center">Searching...</td></tr>';
    
    fetch(`/api/visitors/search?q=${encodeURIComponent(query)}`, {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Search failed');
        }
        return response.json();
    })
    .then(data => {
        if (data.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="6" class="text-center">No matching visitors found</td></tr>';
            return;
        }
        
        // Re-render with search results (same rendering code as loadVisitors)
        tableBody.innerHTML = '';
        data.forEach(visitor => {
            const entryTime = new Date(visitor.entry_time).toLocaleString();
            const exitTime = visitor.exit_time ? new Date(visitor.exit_time).toLocaleString() : 'Not Exited';
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${visitor.visitor_id}</td>
                <td>${visitor.name}</td>
                <td>${visitor.purpose}</td>
                <td>${entryTime}</td>
                <td>${exitTime}</td>
                <td>
                    ${visitor.exit_time ? '' : `
                        <button class="btn record-exit-btn" data-id="${visitor.visitor_id}">
                            <i class="fas fa-sign-out-alt"></i> Record Exit
                        </button>
                    `}
                    <button class="btn delete-btn" data-id="${visitor.visitor_id}">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </td>
            `;
            tableBody.appendChild(row);
        });
        
        // Re-attach event listeners
        document.querySelectorAll('.record-exit-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                recordVisitorExit(this.getAttribute('data-id'));
            });
        });
        
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                deleteVisitor(this.getAttribute('data-id'));
            });
        });
    })
    .catch(error => {
        console.error('Error searching visitors:', error);
        tableBody.innerHTML = '<tr><td colspan="6" class="text-center">Search failed</td></tr>';
        showToast('Search failed', 'error');
    });
}
