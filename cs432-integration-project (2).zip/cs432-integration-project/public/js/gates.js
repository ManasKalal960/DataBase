document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const addGateBtn = document.getElementById('add-gate-btn');
    const gateForm = document.getElementById('gate-form');
    const gateModal = document.getElementById('gate-modal');
    const closeModal = gateModal.querySelector('.close-modal');
    const cancelBtn = document.getElementById('cancel-gate');
    
    // Event listeners
    if (addGateBtn) {
        addGateBtn.addEventListener('click', function() {
            showGateModal();
        });
    }
    
    if (closeModal) {
        closeModal.addEventListener('click', function() {
            gateModal.style.display = 'none';
        });
    }
    
    if (cancelBtn) {
        cancelBtn.addEventListener('click', function() {
            gateModal.style.display = 'none';
        });
    }
    
    if (gateForm) {
        gateForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveGate();
        });
    }
});

// Load gates
function loadGates() {
    const token = localStorage.getItem('token');
    const tableBody = document.getElementById('gates-table-body');
    
    tableBody.innerHTML = '<tr><td colspan="4" class="text-center">Loading...</td></tr>';
    
    fetch('/api/gates', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to fetch gates');
        }
        return response.json();
    })
    .then(data => {
        if (data.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="4" class="text-center">No gates found</td></tr>';
            return;
        }
        
        tableBody.innerHTML = '';
        data.forEach(gate => {
            const statusClass = gate.status === 'Open' ? 'success' : 'danger';
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${gate.gate_id}</td>
                <td>${gate.location}</td>
                <td><span class="status-badge ${statusClass}">${gate.status}</span></td>
                <td>
                    <button class="btn change-status-btn" data-id="${gate.gate_id}" data-status="${gate.status}">
                        <i class="fas fa-exchange-alt"></i> Change Status
                    </button>
                    <button class="btn edit-btn" data-id="${gate.gate_id}">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                </td>
            `;
            tableBody.appendChild(row);
        });
        
        // Add event listeners to action buttons
        document.querySelectorAll('.change-status-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const gateId = this.getAttribute('data-id');
                const currentStatus = this.getAttribute('data-status');
                const newStatus = currentStatus === 'Open' ? 'Closed' : 'Open';
                changeGateStatus(gateId, newStatus);
            });
        });
        
        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                editGate(this.getAttribute('data-id'));
            });
        });
    })
    .catch(error => {
        console.error('Error loading gates:', error);
        tableBody.innerHTML = '<tr><td colspan="4" class="text-center">Error loading gates</td></tr>';
        showToast('Failed to load gates', 'error');
    });
}

// Show gate modal for adding
function showGateModal() {
    document.getElementById('gate-modal-title').textContent = 'Add Gate';
    document.getElementById('gate-form').reset();
    document.getElementById('gate-id').value = '';
    document.getElementById('gate-modal').style.display = 'block';
}

// Edit gate
function editGate(gateId) {
    const token = localStorage.getItem('token');
    
    fetch(`/api/gates/${gateId}`, {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to fetch gate details');
        }
        return response.json();
    })
    .then(gate => {
        document.getElementById('gate-id').value = gate.gate_id;
        document.getElementById('gate-location').value = gate.location;
        document.getElementById('gate-status').value = gate.status;
        
        document.getElementById('gate-modal-title').textContent = 'Edit Gate';
        document.getElementById('gate-modal').style.display = 'block';
    })
    .catch(error => {
        console.error('Error fetching gate details:', error);
        showToast('Failed to load gate details', 'error');
    });
}

// Save gate (create or update)
function saveGate() {
    const token = localStorage.getItem('token');
    const gateId = document.getElementById('gate-id').value;
    const isEdit = !!gateId;
    
    const gateData = {
        location: document.getElementById('gate-location').value,
        status: document.getElementById('gate-status').value
    };
    
    const url = isEdit ? `/api/gates/${gateId}` : '/api/gates';
    const method = isEdit ? 'PUT' : 'POST';
    
    fetch(url, {
        method: method,
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(gateData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to save gate');
        }
        return response.json();
    })
    .then(data => {
        document.getElementById('gate-modal').style.display = 'none';
        showToast(isEdit ? 'Gate updated successfully' : 'Gate added successfully', 'success');
        loadGates();
    })
    .catch(error => {
        console.error('Error saving gate:', error);
        showToast('Failed to save gate', 'error');
    });
}

// Change gate status
function changeGateStatus(gateId, newStatus) {
    const token = localStorage.getItem('token');
    
    fetch(`/api/gates/${gateId}/status`, {
        method: 'PATCH',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ status: newStatus })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to change gate status');
        }
        return response.json();
    })
    .then(data => {
        showToast('Gate status changed successfully', 'success');
        loadGates();
    })
    .catch(error => {
        console.error('Error changing gate status:', error);
        showToast('Failed to change gate status', 'error');
    });
}
