document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const addVehicleBtn = document.getElementById('add-vehicle-btn');
    const vehicleForm = document.getElementById('vehicle-form');
    const vehicleModal = document.getElementById('vehicle-modal');
    const closeModal = vehicleModal.querySelector('.close-modal');
    const cancelBtn = document.getElementById('cancel-vehicle');
    const searchInput = document.getElementById('vehicle-search');
    const searchBtn = document.getElementById('vehicle-search-btn');
    
    // Event listeners
    if (addVehicleBtn) {
        addVehicleBtn.addEventListener('click', function() {
            showVehicleModal();
        });
    }
    
    if (closeModal) {
        closeModal.addEventListener('click', function() {
            vehicleModal.style.display = 'none';
        });
    }
    
    if (cancelBtn) {
        cancelBtn.addEventListener('click', function() {
            vehicleModal.style.display = 'none';
        });
    }
    
    if (vehicleForm) {
        vehicleForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveVehicle();
        });
    }
    
    if (searchBtn) {
        searchBtn.addEventListener('click', function() {
            searchVehicles(searchInput.value);
        });
    }
    
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchVehicles(this.value);
            }
        });
    }
});

// Load vehicles
function loadVehicles() {
    const token = localStorage.getItem('token');
    const tableBody = document.getElementById('vehicles-table-body');
    
    tableBody.innerHTML = '<tr><td colspan="8" class="text-center">Loading...</td></tr>';
    
    fetch('/api/vehicles', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to fetch vehicles');
        }
        return response.json();
    })
    .then(data => {
        if (data.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="8" class="text-center">No vehicles found</td></tr>';
            return;
        }
        
        tableBody.innerHTML = '';
        data.forEach(vehicle => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${vehicle.vehicle_id}</td>
                <td>${vehicle.license_plate}</td>
                <td>${vehicle.owner_name || 'N/A'}</td>
                <td>${vehicle.vehicle_type}</td>
                <td>${vehicle.brand}</td>
                <td>${vehicle.model}</td>
                <td>${vehicle.color}</td>
                <td>
                    <button class="btn edit-btn" data-id="${vehicle.vehicle_id}">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button class="btn delete-btn" data-id="${vehicle.vehicle_id}">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </td>
            `;
            tableBody.appendChild(row);
        });
        
        // Add event listeners to action buttons
        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                editVehicle(this.getAttribute('data-id'));
            });
        });
        
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                deleteVehicle(this.getAttribute('data-id'));
            });
        });
    })
    .catch(error => {
        console.error('Error loading vehicles:', error);
        tableBody.innerHTML = '<tr><td colspan="8" class="text-center">Error loading vehicles</td></tr>';
        showToast('Failed to load vehicles', 'error');
    });
}

// Load college members for select dropdown
function loadOwners() {
    const token = localStorage.getItem('token');
    const ownerSelect = document.getElementById('vehicle-owner');
    
    fetch('/api/collage-members', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => response.json())
    .then(data => {
        ownerSelect.innerHTML = '<option value="">Select owner</option>';
        
        data.forEach(member => {
            const option = document.createElement('option');
            option.value = member.member_id;
            option.textContent = `${member.name} (ID: ${member.member_id})`;
            ownerSelect.appendChild(option);
        });
    })
    .catch(error => {
        console.error('Error loading owners:', error);
        showToast('Failed to load member list', 'error');
    });
}

// Show vehicle modal for adding
function showVehicleModal() {
    document.getElementById('vehicle-modal-title').textContent = 'Add Vehicle';
    document.getElementById('vehicle-form').reset();
    document.getElementById('vehicle-id').value = '';
    loadOwners();
    document.getElementById('vehicle-modal').style.display = 'block';
}

// Load and edit vehicle
function editVehicle(vehicleId) {
    const token = localStorage.getItem('token');
    
    fetch(`/api/vehicles/${vehicleId}`, {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to fetch vehicle details');
        }
        return response.json();
    })
    .then(vehicle => {
        loadOwners().then(() => {
            document.getElementById('vehicle-id').value = vehicle.vehicle_id;
            document.getElementById('license-plate').value = vehicle.license_plate;
            document.getElementById('vehicle-owner').value = vehicle.member_id;
            document.getElementById('vehicle-type').value = vehicle.vehicle_type;
            document.getElementById('vehicle-brand').value = vehicle.brand;
            document.getElementById('vehicle-model').value = vehicle.model;
            document.getElementById('vehicle-color').value = vehicle.color;
            
            document.getElementById('vehicle-modal-title').textContent = 'Edit Vehicle';
            document.getElementById('vehicle-modal').style.display = 'block';
        });
    })
    .catch(error => {
        console.error('Error fetching vehicle details:', error);
        showToast('Failed to load vehicle details', 'error');
    });
}

// Save vehicle (create or update)
function saveVehicle() {
    const token = localStorage.getItem('token');
    const vehicleId = document.getElementById('vehicle-id').value;
    const isEdit = !!vehicleId;
    
    const vehicleData = {
        license_plate: document.getElementById('license-plate').value,
        member_id: document.getElementById('vehicle-owner').value,
        vehicle_type: document.getElementById('vehicle-type').value,
        brand: document.getElementById('vehicle-brand').value,
        model: document.getElementById('vehicle-model').value,
        color: document.getElementById('vehicle-color').value
    };
    
    const url = isEdit ? `/api/vehicles/${vehicleId}` : '/api/vehicles';
    const method = isEdit ? 'PUT' : 'POST';
    
    fetch(url, {
        method: method,
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(vehicleData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to save vehicle');
        }
        return response.json();
    })
    .then(data => {
        document.getElementById('vehicle-modal').style.display = 'none';
        showToast(isEdit ? 'Vehicle updated successfully' : 'Vehicle added successfully', 'success');
        loadVehicles();
    })
    .catch(error => {
        console.error('Error saving vehicle:', error);
        showToast('Failed to save vehicle', 'error');
    });
}

// Delete vehicle
function deleteVehicle(vehicleId) {
    if (!confirm('Are you sure you want to delete this vehicle?')) {
        return;
    }
    
    const token = localStorage.getItem('token');
    
    fetch(`/api/vehicles/${vehicleId}`, {
        method: 'DELETE',
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to delete vehicle');
        }
        return response.json();
    })
    .then(data => {
        showToast('Vehicle deleted successfully', 'success');
        loadVehicles();
    })
    .catch(error => {
        console.error('Error deleting vehicle:', error);
        showToast('Failed to delete vehicle', 'error');
    });
}

// Search vehicles
function searchVehicles(query) {
    if (!query.trim()) {
        loadVehicles();
        return;
    }
    
    const token = localStorage.getItem('token');
    const tableBody = document.getElementById('vehicles-table-body');
    
    tableBody.innerHTML = '<tr><td colspan="8" class="text-center">Searching...</td></tr>';
    
    fetch(`/api/vehicles/search?query=${encodeURIComponent(query)}`, {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Search failed');
        }
        return response.json();
    })
    .then(data => {
        if (data.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="8" class="text-center">No matching vehicles found</td></tr>';
            return;
        }
        
        // Re-render with search results (same as loadVehicles rendering)
        tableBody.innerHTML = '';
        data.forEach(vehicle => {
            // Same rendering code as in loadVehicles
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${vehicle.vehicle_id}</td>
                <td>${vehicle.license_plate}</td>
                <td>${vehicle.owner_name || 'N/A'}</td>
                <td>${vehicle.vehicle_type}</td>
                <td>${vehicle.brand}</td>
                <td>${vehicle.model}</td>
                <td>${vehicle.color}</td>
                <td>
                    <button class="btn edit-btn" data-id="${vehicle.vehicle_id}">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button class="btn delete-btn" data-id="${vehicle.vehicle_id}">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </td>
            `;
            tableBody.appendChild(row);
        });
        
        // Re-attach event listeners
        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                editVehicle(this.getAttribute('data-id'));
            });
        });
        
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                deleteVehicle(this.getAttribute('data-id'));
            });
        });
    })
    .catch(error => {
        console.error('Error searching vehicles:', error);
        tableBody.innerHTML = '<tr><td colspan="8" class="text-center">Search failed</td></tr>';
        showToast('Search failed', 'error');
    });
}
