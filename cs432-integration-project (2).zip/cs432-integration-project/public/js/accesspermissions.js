document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const addPermissionBtn = document.getElementById('add-permission-btn');
    const permissionForm = document.getElementById('permission-form');
    const permissionModal = document.getElementById('permission-modal');
    const closeModal = permissionModal.querySelector('.close-modal');
    const cancelBtn = document.getElementById('cancel-permission');
    const filterBtn = document.getElementById('filter-permission-btn');
    const roleFilter = document.getElementById('role-filter');
    
    // Event listeners
    if (addPermissionBtn) {
        addPermissionBtn.addEventListener('click', function() {
            showPermissionModal();
        });
    }
    
    if (closeModal) {
        closeModal.addEventListener('click', function() {
            permissionModal.style.display = 'none';
        });
    }
    
    if (cancelBtn) {
        cancelBtn.addEventListener('click', function() {
            permissionModal.style.display = 'none';
        });
    }
    
    if (permissionForm) {
        permissionForm.addEventListener('submit', function(e) {
            e.preventDefault();
            savePermission();
        });
    }
    
    if (filterBtn) {
        filterBtn.addEventListener('click', function() {
            loadPermissions(roleFilter.value);
        });
    }
});

// Load permissions
function loadPermissions(role = '') {
    const token = localStorage.getItem('token');
    const tableBody = document.getElementById('permissions-table-body');
    
    tableBody.innerHTML = '<tr><td colspan="5" class="text-center">Loading...</td></tr>';
    
    let url = '/api/access-permissions';
    if (role) {
        url += `/${role}`;
    }
    
    fetch(url, {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to fetch permissions');
        }
        return response.json();
    })
    .then(data => {
        if (data.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="5" class="text-center">No permissions found</td></tr>';
            return;
        }
        
        tableBody.innerHTML = '';
        data.forEach(permission => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${permission.permission_id}</td>
                <td>${permission.role}</td>
                <td>${permission.resource}</td>
                <td>${permission.action}</td>
                <td>
                    <button class="btn edit-btn" data-id="${permission.permission_id}">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button class="btn delete-btn" data-id="${permission.permission_id}">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </td>
            `;
            tableBody.appendChild(row);
        });
        
        // Add event listeners to action buttons
        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                editPermission(this.getAttribute('data-id'));
            });
        });
        
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                deletePermission(this.getAttribute('data-id'));
            });
        });
    })
    .catch(error => {
        console.error('Error loading permissions:', error);
        tableBody.innerHTML = '<tr><td colspan="5" class="text-center">Error loading permissions</td></tr>';
        showToast('Failed to load permissions', 'error');
    });
}

// Show permission modal for adding
function showPermissionModal() {
    document.getElementById('permission-modal-title').textContent = 'Add Permission';
    document.getElementById('permission-form').reset();
    document.getElementById('permission-id').value = '';
    document.getElementById('permission-modal').style.display = 'block';
}

// Edit permission
function editPermission(permissionId) {
    const token = localStorage.getItem('token');
    
    fetch(`/api/access-permissions/${permissionId}`, {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to fetch permission details');
        }
        return response.json();
    })
    .then(permission => {
        document.getElementById('permission-id').value = permission.permission_id;
        document.getElementById('permission-role').value = permission.role;
        document.getElementById('permission-resource').value = permission.resource;
        document.getElementById('permission-action').value = permission.action;
        
        document.getElementById('permission-modal-title').textContent = 'Edit Permission';
        document.getElementById('permission-modal').style.display = 'block';
    })
    .catch(error => {
        console.error('Error fetching permission details:', error);
        showToast('Failed to load permission details', 'error');
    });
}

// Save permission (create or update)
function savePermission() {
    const token = localStorage.getItem('token');
    const permissionId = document.getElementById('permission-id').value;
    const isEdit = !!permissionId;
    
    const permissionData = {
        role: document.getElementById('permission-role').value,
        resource: document.getElementById('permission-resource').value,
        action: document.getElementById('permission-action').value
    };
    
    const url = isEdit ? `/api/access-permissions/${permissionId}` : '/api/access-permissions';
    const method = isEdit ? 'PUT' : 'POST';
    
    fetch(url, {
        method: method,
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(permissionData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to save permission');
        }
        return response.json();
    })
    .then(data => {
        document.getElementById('permission-modal').style.display = 'none';
        showToast(isEdit ? 'Permission updated successfully' : 'Permission added successfully', 'success');
        loadPermissions(document.getElementById('role-filter').value);
    })
    .catch(error => {
        console.error('Error saving permission:', error);
        showToast('Failed to save permission', 'error');
    });
}

// Delete permission
function deletePermission(permissionId) {
    if (!confirm('Are you sure you want to delete this permission?')) {
        return;
    }
    
    const token = localStorage.getItem('token');
    
    fetch(`/api/access-permissions/${permissionId}`, {
        method: 'DELETE',
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to delete permission');
        }
        return response.json();
    })
    .then(data => {
        showToast('Permission deleted successfully', 'success');
        loadPermissions(document.getElementById('role-filter').value);
    })
    .catch(error => {
        console.error('Error deleting permission:', error);
        showToast('Failed to delete permission', 'error');
    });
}
