document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const addCollegeMemberBtn = document.getElementById('add-college-member-btn');
    const collegeMemberForm = document.getElementById('college-member-form');
    const collegeMemberModal = document.getElementById('college-member-modal');
    const closeModal = collegeMemberModal.querySelector('.close-modal');
    const cancelBtn = document.getElementById('cancel-college-member');
    const searchInput = document.getElementById('college-member-search');
    const searchBtn = document.getElementById('college-member-search-btn');
    
    // Event listeners
    if (addCollegeMemberBtn) {
        addCollegeMemberBtn.addEventListener('click', function() {
            showCollegeMemberModal();
        });
    }
    
    if (closeModal) {
        closeModal.addEventListener('click', function() {
            collegeMemberModal.style.display = 'none';
        });
    }
    
    if (cancelBtn) {
        cancelBtn.addEventListener('click', function() {
            collegeMemberModal.style.display = 'none';
        });
    }
    
    if (collegeMemberForm) {
        collegeMemberForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveCollegeMember();
        });
    }
    
    if (searchBtn) {
        searchBtn.addEventListener('click', function() {
            searchCollegeMembers(searchInput.value);
        });
    }
    
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchCollegeMembers(this.value);
            }
        });
    }
});

// Load college members
function loadCollegeMembers() {
    const token = localStorage.getItem('token');
    const tableBody = document.getElementById('college-members-table-body');
    
    tableBody.innerHTML = '<tr><td colspan="6" class="text-center">Loading...</td></tr>';
    
    fetch('/api/collage-members', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to fetch college members');
        }
        return response.json();
    })
    .then(data => {
        if (data.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="6" class="text-center">No college members found</td></tr>';
            return;
        }
        
        tableBody.innerHTML = '';
        data.forEach(member => {
            const joinedDate = new Date(member.date_joined).toLocaleDateString();
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${member.member_id}</td>
                <td>${member.name}</td>
                <td>${member.email}</td>
                <td><span class="status-badge ${member.status.toLowerCase()}">${member.status}</span></td>
                <td>${joinedDate}</td>
                <td>
                    <button class="btn edit-btn" data-id="${member.member_id}">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button class="btn delete-btn" data-id="${member.member_id}">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </td>
            `;
            tableBody.appendChild(row);
        });
        
        // Add event listeners to action buttons
        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                editCollegeMember(this.getAttribute('data-id'));
            });
        });
        
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                deleteCollegeMember(this.getAttribute('data-id'));
            });
        });
    })
    .catch(error => {
        console.error('Error loading college members:', error);
        tableBody.innerHTML = '<tr><td colspan="6" class="text-center">Error loading college members</td></tr>';
        showToast('Failed to load college members', 'error');
    });
}

// Show college member modal for adding
function showCollegeMemberModal() {
    document.getElementById('college-member-modal-title').textContent = 'Add College Member';
    document.getElementById('college-member-form').reset();
    document.getElementById('college-member-id').value = '';
    document.getElementById('college-member-modal').style.display = 'block';
}

// Load and edit college member
function editCollegeMember(memberId) {
    const token = localStorage.getItem('token');
    
    fetch(`/api/collage-members/${memberId}`, {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to fetch college member details');
        }
        return response.json();
    })
    .then(member => {
        document.getElementById('college-member-id').value = member.member_id;
        document.getElementById('college-member-name').value = member.name;
        document.getElementById('college-member-email').value = member.email;
        document.getElementById('college-member-status').value = member.status;
        
        document.getElementById('college-member-modal-title').textContent = 'Edit College Member';
        document.getElementById('college-member-modal').style.display = 'block';
    })
    .catch(error => {
        console.error('Error fetching college member details:', error);
        showToast('Failed to load member details', 'error');
    });
}

// Save college member (create or update)
function saveCollegeMember() {
    const token = localStorage.getItem('token');
    const memberId = document.getElementById('college-member-id').value;
    const isEdit = !!memberId;
    
    const memberData = {
        name: document.getElementById('college-member-name').value,
        email: document.getElementById('college-member-email').value,
        status: document.getElementById('college-member-status').value
    };
    
    const url = isEdit ? `/api/collage-members/${memberId}` : '/api/collage-members';
    const method = isEdit ? 'PUT' : 'POST';
    
    fetch(url, {
        method: method,
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(memberData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to save college member');
        }
        return response.json();
    })
    .then(data => {
        document.getElementById('college-member-modal').style.display = 'none';
        showToast(isEdit ? 'Member updated successfully' : 'Member added successfully', 'success');
        loadCollegeMembers();
    })
    .catch(error => {
        console.error('Error saving college member:', error);
        showToast('Failed to save member', 'error');
    });
}

// Delete college member
function deleteCollegeMember(memberId) {
    if (!confirm('Are you sure you want to delete this member?')) {
        return;
    }
    
    const token = localStorage.getItem('token');
    
    fetch(`/api/collage-members/${memberId}`, {
        method: 'DELETE',
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to delete college member');
        }
        return response.json();
    })
    .then(data => {
        showToast('Member deleted successfully', 'success');
        loadCollegeMembers();
    })
    .catch(error => {
        console.error('Error deleting college member:', error);
        showToast('Failed to delete member', 'error');
    });
}

// Search college members
function searchCollegeMembers(query) {
    if (!query.trim()) {
        loadCollegeMembers();
        return;
    }
    
    const token = localStorage.getItem('token');
    const tableBody = document.getElementById('college-members-table-body');
    
    tableBody.innerHTML = '<tr><td colspan="6" class="text-center">Searching...</td></tr>';
    
    fetch(`/api/collage-members/search?query=${encodeURIComponent(query)}`, {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Search failed');
        }
        return response.json();
    })
    .then(data => {
        if (data.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="6" class="text-center">No matching members found</td></tr>';
            return;
        }
        
        // Re-render with search results (same as loadCollegeMembers rendering)
        tableBody.innerHTML = '';
        data.forEach(member => {
            // Same rendering code as in loadCollegeMembers
            const joinedDate = new Date(member.date_joined).toLocaleDateString();
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${member.member_id}</td>
                <td>${member.name}</td>
                <td>${member.email}</td>
                <td><span class="status-badge ${member.status.toLowerCase()}">${member.status}</span></td>
                <td>${joinedDate}</td>
                <td>
                    <button class="btn edit-btn" data-id="${member.member_id}">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button class="btn delete-btn" data-id="${member.member_id}">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </td>
            `;
            tableBody.appendChild(row);
        });
        
        // Re-attach event listeners
        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                editCollegeMember(this.getAttribute('data-id'));
            });
        });
        
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                deleteCollegeMember(this.getAttribute('data-id'));
            });
        });
    })
    .catch(error => {
        console.error('Error searching college members:', error);
        tableBody.innerHTML = '<tr><td colspan="6" class="text-center">Search failed</td></tr>';
        showToast('Search failed', 'error');
    });
}
