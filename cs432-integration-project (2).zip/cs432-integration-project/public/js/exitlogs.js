document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const addExitLogBtn = document.getElementById('add-exit-log-btn');
    const exitLogForm = document.getElementById('exit-log-form');
    const exitLogModal = document.getElementById('exit-log-modal');
    const closeModal = exitLogModal.querySelector('.close-modal');
    const cancelBtn = document.getElementById('cancel-exit-log');
    const filterBtn = document.getElementById('exit-filter-btn');
    
    // Event listeners
    if (addExitLogBtn) {
        addExitLogBtn.addEventListener('click', function() {
            showExitLogModal();
        });
    }
    
    if (closeModal) {
        closeModal.addEventListener('click', function() {
            exitLogModal.style.display = 'none';
        });
    }
    
    if (cancelBtn) {
        cancelBtn.addEventListener('click', function() {
            exitLogModal.style.display = 'none';
        });
    }
    
    if (exitLogForm) {
        exitLogForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveExitLog();
        });
    }
    
    if (filterBtn) {
        filterBtn.addEventListener('click', function() {
            const from = document.getElementById('exit-date-from').value;
            const to = document.getElementById('exit-date-to').value;
            loadExitLogs(from, to);
        });
    }
});

// Load exit logs
function loadExitLogs(fromDate = null, toDate = null) {
    const token = localStorage.getItem('token');
    const tableBody = document.getElementById('exit-logs-table-body');
    
    tableBody.innerHTML = '<tr><td colspan="5" class="text-center">Loading...</td></tr>';
    
    let url = '/api/exit-logs';
    if (fromDate || toDate) {
        url += '?';
        if (fromDate) url += `from=${fromDate}`;
        if (fromDate && toDate) url += '&';
        if (toDate) url += `to=${toDate}`;
    }
    
    fetch(url, {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to fetch exit logs');
        }
        return response.json();
    })
    .then(data => {
        if (data.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="5" class="text-center">No exit logs found</td></tr>';
            return;
        }
        
        tableBody.innerHTML = '';
        data.forEach(exit => {
            const exitTime = new Date(exit.exit_time).toLocaleString();
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${exit.log_id}</td>
                <td>${exit.visitor_name}</td>
                <td>${exit.location}</td>
                <td>${exitTime}</td>
                <td>
                    <button class="btn delete-btn" data-id="${exit.log_id}">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </td>
            `;
            tableBody.appendChild(row);
        });
        
        // Add event listeners to delete buttons
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                deleteExitLog(this.getAttribute('data-id'));
            });
        });
    })
    .catch(error => {
        console.error('Error loading exit logs:', error);
        tableBody.innerHTML = '<tr><td colspan="5" class="text-center">Error loading exit logs</td></tr>';
        showToast('Failed to load exit logs', 'error');
    });
}

// Load visitors for select dropdown (who have entered but not exited)
function loadVisitorsForSelect() {
    const token = localStorage.getItem('token');
    const visitorSelect = document.getElementById('exit-visitor');
    
    fetch('/api/visitors/active', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => response.json())
    .then(data => {
        visitorSelect.innerHTML = '<option value="">Select visitor</option>';
        
        data.forEach(visitor => {
            const option = document.createElement('option');
            option.value = visitor.visitor_id;
            option.textContent = visitor.name;
            visitorSelect.appendChild(option);
        });
    })
    .catch(error => {
        console.error('Error loading visitors:', error);
        showToast('Failed to load visitor list', 'error');
    });
}

// Load gates for select dropdown
function loadGatesForSelect() {
    const token = localStorage.getItem('token');
    const gateSelect = document.getElementById('exit-gate');
    
    fetch('/api/gates', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => response.json())
    .then(data => {
        // Filter to only show open gates
        const openGates = data.filter(gate => gate.status === 'Open');
        
        gateSelect.innerHTML = '<option value="">Select gate</option>';
        
        openGates.forEach(gate => {
            const option = document.createElement('option');
            option.value = gate.gate_id;
            option.textContent = gate.location;
            gateSelect.appendChild(option);
        });
    })
    .catch(error => {
        console.error('Error loading gates:', error);
        showToast('Failed to load gate list', 'error');
    });
}

// Show exit log modal
function showExitLogModal() {
    document.getElementById('exit-log-form').reset();
    loadVisitorsForSelect();
    loadGatesForSelect();
    document.getElementById('exit-log-modal').style.display = 'block';
}

// Save exit log
function saveExitLog() {
    const token = localStorage.getItem('token');
    
    const exitData = {
        visitor_id: document.getElementById('exit-visitor').value,
        gate_id: document.getElementById('exit-gate').value
    };
    
    fetch('/api/exit-logs', {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(exitData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to save exit log');
        }
        return response.json();
    })
    .then(data => {
        document.getElementById('exit-log-modal').style.display = 'none';
        showToast('Exit log added successfully', 'success');
        loadExitLogs();
    })
    .catch(error => {
        console.error('Error saving exit log:', error);
        showToast('Failed to add exit log', 'error');
    });
}

// Delete exit log
function deleteExitLog(logId) {
    if (!confirm('Are you sure you want to delete this exit log?')) {
        return;
    }
    
    const token = localStorage.getItem('token');
    
    fetch(`/api/exit-logs/${logId}`, {
        method: 'DELETE',
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to delete exit log');
        }
        return response.json();
    })
    .then(data => {
        showToast('Exit log deleted successfully', 'success');
        loadExitLogs();
    })
    .catch(error => {
        console.error('Error deleting exit log:', error);
        showToast('Failed to delete exit log', 'error');
    });
}
