document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const addParkingBtn = document.getElementById('add-parking-btn');
    const parkingForm = document.getElementById('parking-form');
    const parkingModal = document.getElementById('parking-modal');
    const closeModal = parkingModal.querySelector('.close-modal');
    const cancelBtn = document.getElementById('cancel-parking');
    const searchInput = document.getElementById('parking-search');
    const searchBtn = document.getElementById('parking-search-btn');
    
    // Event listeners
    if (addParkingBtn) {
        addParkingBtn.addEventListener('click', function() {
            showParkingModal();
        });
    }
    
    if (closeModal) {
        closeModal.addEventListener('click', function() {
            parkingModal.style.display = 'none';
        });
    }
    
    if (cancelBtn) {
        cancelBtn.addEventListener('click', function() {
            parkingModal.style.display = 'none';
        });
    }
    
    if (parkingForm) {
        parkingForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveParking();
        });
    }
    
    if (searchBtn) {
        searchBtn.addEventListener('click', function() {
            searchParkingLogs(searchInput.value);
        });
    }
    
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchParkingLogs(this.value);
            }
        });
    }
});

// Load parking logs
function loadParkingLogs() {
    const token = localStorage.getItem('token');
    const tableBody = document.getElementById('parking-table-body');
    
    tableBody.innerHTML = '<tr><td colspan="7" class="text-center">Loading...</td></tr>';
    
    fetch('/api/parking', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to fetch parking logs');
        }
        return response.json();
    })
    .then(data => {
        if (data.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="7" class="text-center">No parking logs found</td></tr>';
            return;
        }
        
        tableBody.innerHTML = '';
        data.forEach(log => {
            const entryTime = new Date(log.entry_time).toLocaleString();
            const exitTime = log.exit_time ? new Date(log.exit_time).toLocaleString() : 'Not Exited';
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${log.log_id}</td>
                <td>${log.vehicle_type}</td>
                <td>${log.license_plate}</td>
                <td>${log.owner_name}</td>
                <td>${entryTime}</td>
                <td>${exitTime}</td>
                <td>
                    ${log.exit_time ? '' : `
                        <button class="btn record-exit-btn" data-id="${log.log_id}">
                            <i class="fas fa-sign-out-alt"></i> Record Exit
                        </button>
                    `}
                    <button class="btn delete-btn" data-id="${log.log_id}">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </td>
            `;
            tableBody.appendChild(row);
        });
        
        // Add event listeners to action buttons
        document.querySelectorAll('.record-exit-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                recordParkingExit(this.getAttribute('data-id'));
            });
        });
        
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                deleteParkingLog(this.getAttribute('data-id'));
            });
        });
    })
    .catch(error => {
        console.error('Error loading parking logs:', error);
        tableBody.innerHTML = '<tr><td colspan="7" class="text-center">Error loading parking logs</td></tr>';
        showToast('Failed to load parking logs', 'error');
    });
}

// Load vehicles for select dropdown
function loadVehiclesForSelect() {
    const token = localStorage.getItem('token');
    const vehicleSelect = document.getElementById('parking-vehicle');
    
    fetch('/api/vehicles', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => response.json())
    .then(data => {
        vehicleSelect.innerHTML = '<option value="">Select vehicle</option>';
        
        data.forEach(vehicle => {
            const option = document.createElement('option');
            option.value = vehicle.vehicle_id;
            option.textContent = `${vehicle.license_plate} (${vehicle.brand} ${vehicle.model})`;
            vehicleSelect.appendChild(option);
        });
    })
    .catch(error => {
        console.error('Error loading vehicles:', error);
        showToast('Failed to load vehicle list', 'error');
    });
}

// Show parking modal
function showParkingModal() {
    document.getElementById('parking-form').reset();
    loadVehiclesForSelect();
    document.getElementById('parking-modal').style.display = 'block';
}

// Save parking entry
function saveParking() {
    const token = localStorage.getItem('token');
    
    const parkingData = {
        vehicle_id: document.getElementById('parking-vehicle').value
    };
    
    fetch('/api/parking', {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(parkingData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to save parking entry');
        }
        return response.json();
    })
    .then(data => {
        document.getElementById('parking-modal').style.display = 'none';
        showToast('Parking entry recorded successfully', 'success');
        loadParkingLogs();
    })
    .catch(error => {
        console.error('Error saving parking entry:', error);
        showToast('Failed to record parking entry', 'error');
    });
}

// Record parking exit
function recordParkingExit(logId) {
    const token = localStorage.getItem('token');
    
    fetch(`/api/parking/${logId}/exit`, {
        method: 'PATCH',
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to record exit');
        }
        return response.json();
    })
    .then(data => {
        showToast('Parking exit recorded successfully', 'success');
        loadParkingLogs();
    })
    .catch(error => {
        console.error('Error recording exit:', error);
        showToast('Failed to record exit', 'error');
    });
}

// Delete parking log
function deleteParkingLog(logId) {
    if (!confirm('Are you sure you want to delete this parking log?')) {
        return;
    }
    
    const token = localStorage.getItem('token');
    
    fetch(`/api/parking/${logId}`, {
        method: 'DELETE',
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to delete parking log');
        }
        return response.json();
    })
    .then(data => {
        showToast('Parking log deleted successfully', 'success');
        loadParkingLogs();
    })
    .catch(error => {
        console.error('Error deleting parking log:', error);
        showToast('Failed to delete parking log', 'error');
    });
}

// Search parking logs
function searchParkingLogs(query) {
    if (!query.trim()) {
        loadParkingLogs();
        return;
    }
    
    const token = localStorage.getItem('token');
    const tableBody = document.getElementById('parking-table-body');
    
    tableBody.innerHTML = '<tr><td colspan="7" class="text-center">Searching...</td></tr>';
    
    fetch(`/api/parking/search?q=${encodeURIComponent(query)}`, {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Search failed');
        }
        return response.json();
    })
    .then(data => {
        if (data.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="7" class="text-center">No matching parking logs found</td></tr>';
            return;
        }
        
        // Re-render with search results (same rendering code as loadParkingLogs)
        tableBody.innerHTML = '';
        data.forEach(log => {
            const entryTime = new Date(log.entry_time).toLocaleString();
            const exitTime = log.exit_time ? new Date(log.exit_time).toLocaleString() : 'Not Exited';
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${log.log_id}</td>
                <td>${log.vehicle_type}</td>
                <td>${log.license_plate}</td>
                <td>${log.owner_name}</td>
                <td>${entryTime}</td>
                <td>${exitTime}</td>
                <td>
                    ${log.exit_time ? '' : `
                        <button class="btn record-exit-btn" data-id="${log.log_id}">
                            <i class="fas fa-sign-out-alt"></i> Record Exit
                        </button>
                    `}
                    <button class="btn delete-btn" data-id="${log.log_id}">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </td>
            `;
            tableBody.appendChild(row);
        });
        
        // Re-attach event listeners
        document.querySelectorAll('.record-exit-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                recordParkingExit(this.getAttribute('data-id'));
            });
        });
        
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                deleteParkingLog(this.getAttribute('data-id'));
            });
        });
    })
    .catch(error => {
        console.error('Error searching parking logs:', error);
        tableBody.innerHTML = '<tr><td colspan="7" class="text-center">Search failed</td></tr>';
        showToast('Search failed', 'error');
    });
}
