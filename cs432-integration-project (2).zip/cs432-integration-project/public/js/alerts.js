document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const addAlertBtn = document.getElementById('add-alert-btn');
    const alertForm = document.getElementById('alert-form');
    const alertModal = document.getElementById('alert-modal');
    const closeModal = alertModal.querySelector('.close-modal');
    const cancelBtn = document.getElementById('cancel-alert');
    const filterBtn = document.getElementById('filter-alert-btn');
    const severityFilter = document.getElementById('severity-filter');
    const statusFilter = document.getElementById('status-filter');
    
    // Event listeners
    if (addAlertBtn) {
        addAlertBtn.addEventListener('click', function() {
            showAlertModal();
        });
    }
    
    if (closeModal) {
        closeModal.addEventListener('click', function() {
            alertModal.style.display = 'none';
        });
    }
    
    if (cancelBtn) {
        cancelBtn.addEventListener('click', function() {
            alertModal.style.display = 'none';
        });
    }
    
    if (alertForm) {
        alertForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveAlert();
        });
    }
    
    if (filterBtn) {
        filterBtn.addEventListener('click', function() {
            loadAlerts(severityFilter.value, statusFilter.value);
        });
    }
});

// Load alerts
function loadAlerts(severity = '', status = '') {
    const token = localStorage.getItem('token');
    const tableBody = document.getElementById('alerts-table-body');
    
    tableBody.innerHTML = '<tr><td colspan="6" class="text-center">Loading...</td></tr>';
    
    let url = '/api/alerts';
    const params = [];
    if (severity) params.push(`severity=${severity}`);
    if (status) params.push(`status=${status}`);
    
    if (params.length > 0) {
        url += '?' + params.join('&');
    }
    
    fetch(url, {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to fetch alerts');
        }
        return response.json();
    })
    .then(data => {
        if (data.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="6" class="text-center">No alerts found</td></tr>';
            return;
        }
        
        tableBody.innerHTML = '';
        data.forEach(alert => {
            const timestamp = new Date(alert.timestamp).toLocaleString();
            const severityClass = alert.severity.toLowerCase();
            const statusClass = alert.resolved ? 'resolved' : 'active';
            const status = alert.resolved ? 'Resolved' : 'Active';
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${alert.alert_id}</td>
                <td>${alert.description}</td>
                <td><span class="severity-badge ${severityClass}">${alert.severity}</span></td>
                <td><span class="status-badge ${statusClass}">${status}</span></td>
                <td>${timestamp}</td>
                <td>
                    ${!alert.resolved ? `
                        <button class="btn resolve-btn" data-id="${alert.alert_id}">
                            <i class="fas fa-check"></i> Resolve
                        </button>
                    ` : ''}
                    <button class="btn delete-btn" data-id="${alert.alert_id}">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </td>
            `;
            tableBody.appendChild(row);
        });
        
        // Add event listeners to action buttons
        document.querySelectorAll('.resolve-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                resolveAlert(this.getAttribute('data-id'));
            });
        });
        
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                deleteAlert(this.getAttribute('data-id'));
            });
        });
    })
    .catch(error => {
        console.error('Error loading alerts:', error);
        tableBody.innerHTML = '<tr><td colspan="6" class="text-center">Error loading alerts</td></tr>';
        showToast('Failed to load alerts', 'error');
    });
}

// Show alert modal for adding
function showAlertModal() {
    document.getElementById('alert-modal-title').textContent = 'Add Alert';
    document.getElementById('alert-form').reset();
    document.getElementById('alert-id').value = '';
    document.getElementById('alert-modal').style.display = 'block';
}

// Save alert
function saveAlert() {
    const token = localStorage.getItem('token');
    
    const alertData = {
        description: document.getElementById('alert-description').value,
        severity: document.getElementById('alert-severity').value
    };
    
    fetch('/api/alerts', {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(alertData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to save alert');
        }
        return response.json();
    })
    .then(data => {
        document.getElementById('alert-modal').style.display = 'none';
        showToast('Alert added successfully', 'success');
        loadAlerts(document.getElementById('severity-filter').value, document.getElementById('status-filter').value);
    })
    .catch(error => {
        console.error('Error saving alert:', error);
        showToast('Failed to add alert', 'error');
    });
}

// Resolve alert
function resolveAlert(alertId) {
    const token = localStorage.getItem('token');
    
    fetch(`/api/alerts/${alertId}/resolve`, {
        method: 'PATCH',
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to resolve alert');
        }
        return response.json();
    })
    .then(data => {
        showToast('Alert resolved successfully', 'success');
        loadAlerts(document.getElementById('severity-filter').value, document.getElementById('status-filter').value);
    })
    .catch(error => {
        console.error('Error resolving alert:', error);
        showToast('Failed to resolve alert', 'error');
    });
}

// Delete alert
function deleteAlert(alertId) {
    if (!confirm('Are you sure you want to delete this alert?')) {
        return;
    }
    
    const token = localStorage.getItem('token');
    
    fetch(`/api/alerts/${alertId}`, {
        method: 'DELETE',
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to delete alert');
        }
        return response.json();
    })
    .then(data => {
        showToast('Alert deleted successfully', 'success');
        loadAlerts(document.getElementById('severity-filter').value, document.getElementById('status-filter').value);
    })
    .catch(error => {
        console.error('Error deleting alert:', error);
        showToast('Failed to delete alert', 'error');
    });
}
