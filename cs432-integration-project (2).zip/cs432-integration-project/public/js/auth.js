document.addEventListener('DOMContentLoaded', function () {
    // Tab switching for Login/Sign Up
    const tabs = document.querySelectorAll('.auth-tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', function () {
            tabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            document.querySelectorAll('.auth-form').forEach(form => form.classList.remove('active'));
            const tabName = this.getAttribute('data-tab');
            document.getElementById(`${tabName}-form`).classList.add('active');
        });
    });

    // Show/hide dashboard or login based on token
    const token = localStorage.getItem('token');
    if (token) {
        document.getElementById('auth-container').style.display = 'none';
        document.getElementById('app-container').style.display = 'block';
        if (typeof loadDashboardData === 'function') loadDashboardData();
    } else {
        document.getElementById('auth-container').style.display = 'block';
        document.getElementById('app-container').style.display = 'none';
    }

    // Login Form
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function (e) {
            e.preventDefault();
            const credentials = {
                userid: document.getElementById('login-email').value,
                password: document.getElementById('login-password').value,
            };
            fetch('/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(credentials),
            })
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        document.getElementById('login-message').textContent = data.error;
                        document.getElementById('login-message').className = 'message error';
                    } else {
                        localStorage.setItem('token', data.token);
                        localStorage.setItem('user', JSON.stringify({ id: data.userId, role: data.role }));
                        document.getElementById('auth-container').style.display = 'none';
                        document.getElementById('app-container').style.display = 'block';
                        if (typeof loadDashboardData === 'function') loadDashboardData();
                    }
                })
                .catch(error => {
                    document.getElementById('login-message').textContent = 'Server error. Please try again.';
                    document.getElementById('login-message').className = 'message error';
                });
        });
    }

    // Signup Form
    const signupForm = document.getElementById('signup-form');
    if (signupForm) {
        signupForm.addEventListener('submit', function (e) {
            e.preventDefault();
            const userData = {
                memberid: document.getElementById('signup-userid').value,
                name: document.getElementById('signup-name').value,
                email: document.getElementById('signup-email').value,
                role: document.getElementById('signup-role').value,
                dob: document.getElementById('signup-dob').value,
                password: document.getElementById('signup-password').value,
            };
            fetch('/api/members', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(userData),
            })
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        document.getElementById('signup-message').textContent = data.error;
                        document.getElementById('signup-message').className = 'message error';
                    } else {
                        // Auto-login after signup
                        fetch('/api/auth/login', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ userid: userData.memberid, password: userData.password }),
                        })
                            .then(response => response.json())
                            .then(loginData => {
                                if (loginData.error) {
                                    document.querySelector('[data-tab="login"]').click();
                                    document.getElementById('login-message').textContent = 'Registration successful. Please log in.';
                                    document.getElementById('login-message').className = 'message success';
                                } else {
                                    localStorage.setItem('token', loginData.token);
                                    localStorage.setItem('user', JSON.stringify({ id: loginData.userId, role: loginData.role }));
                                    document.getElementById('auth-container').style.display = 'none';
                                    document.getElementById('app-container').style.display = 'block';
                                    if (typeof loadDashboardData === 'function') loadDashboardData();
                                }
                            });
                    }
                })
                .catch(error => {
                    document.getElementById('signup-message').textContent = 'Server error. Please try again.';
                    document.getElementById('signup-message').className = 'message error';
                });
        });
    }

    // Logout Button
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function () {
            localStorage.removeItem('token');
            localStorage.removeItem('user');
            window.location.reload();
        });
    }
});
