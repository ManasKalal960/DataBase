document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const addStaffBtn = document.getElementById('add-staff-btn');
    const staffForm = document.getElementById('staff-form');
    const staffModal = document.getElementById('staff-modal');
    const closeModal = staffModal.querySelector('.close-modal');
    const cancelBtn = document.getElementById('cancel-staff');
    const searchInput = document.getElementById('staff-search');
    const searchBtn = document.getElementById('staff-search-btn');
    
    // Event listeners
    if (addStaffBtn) {
        addStaffBtn.addEventListener('click', function() {
            showStaffModal();
        });
    }
    
    if (closeModal) {
        closeModal.addEventListener('click', function() {
            staffModal.style.display = 'none';
        });
    }
    
    if (cancelBtn) {
        cancelBtn.addEventListener('click', function() {
            staffModal.style.display = 'none';
        });
    }
    
    if (staffForm) {
        staffForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveStaff();
        });
    }
    
    if (searchBtn) {
        searchBtn.addEventListener('click', function() {
            searchStaff(searchInput.value);
        });
    }
    
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchStaff(this.value);
            }
        });
    }
});

// Load security staff
function loadSecurityStaff() {
    const token = localStorage.getItem('token');
    const tableBody = document.getElementById('staff-table-body');
    
    tableBody.innerHTML = '<tr><td colspan="5" class="text-center">Loading...</td></tr>';
    
    fetch('/api/security-staff', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to fetch security staff');
        }
        return response.json();
    })
    .then(data => {
        if (data.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="5" class="text-center">No security staff found</td></tr>';
            return;
        }
        
        tableBody.innerHTML = '';
        data.forEach(staff => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${staff.staff_id}</td>
                <td>${staff.name}</td>
                <td>${staff.role}</td>
                <td>${staff.contact_number || 'N/A'}</td>
                <td>
                    <button class="btn edit-btn" data-id="${staff.staff_id}">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button class="btn delete-btn" data-id="${staff.staff_id}">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </td>
            `;
            tableBody.appendChild(row);
        });
        
        // Add event listeners to action buttons
        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                editStaff(this.getAttribute('data-id'));
            });
        });
        
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                deleteStaff(this.getAttribute('data-id'));
            });
        });
    })
    .catch(error => {
        console.error('Error loading security staff:', error);
        tableBody.innerHTML = '<tr><td colspan="5" class="text-center">Error loading security staff</td></tr>';
        showToast('Failed to load security staff', 'error');
    });
}

// Show staff modal for adding
function showStaffModal() {
    document.getElementById('staff-modal-title').textContent = 'Add Security Staff';
    document.getElementById('staff-form').reset();
    document.getElementById('staff-id').value = '';
    document.getElementById('staff-modal').style.display = 'block';
}

// Edit staff
function editStaff(staffId) {
    const token = localStorage.getItem('token');
    
    fetch(`/api/security-staff/${staffId}`, {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to fetch staff details');
        }
        return response.json();
    })
    .then(staff => {
        document.getElementById('staff-id').value = staff.staff_id;
        document.getElementById('staff-name').value = staff.name;
        document.getElementById('staff-role').value = staff.role;
        document.getElementById('staff-contact').value = staff.contact_number || '';
        
        document.getElementById('staff-modal-title').textContent = 'Edit Security Staff';
        document.getElementById('staff-modal').style.display = 'block';
    })
    .catch(error => {
        console.error('Error fetching staff details:', error);
        showToast('Failed to load staff details', 'error');
    });
}

// Save staff (create or update)
function saveStaff() {
    const token = localStorage.getItem('token');
    const staffId = document.getElementById('staff-id').value;
    const isEdit = !!staffId;
    
    const staffData = {
        name: document.getElementById('staff-name').value,
        role: document.getElementById('staff-role').value,
        contact_number: document.getElementById('staff-contact').value || null
    };
    
    const url = isEdit ? `/api/security-staff/${staffId}` : '/api/security-staff';
    const method = isEdit ? 'PUT' : 'POST';
    
    fetch(url, {
        method: method,
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(staffData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to save staff');
        }
        return response.json();
    })
    .then(data => {
        document.getElementById('staff-modal').style.display = 'none';
        showToast(isEdit ? 'Staff updated successfully' : 'Staff added successfully', 'success');
        loadSecurityStaff();
    })
    .catch(error => {
        console.error('Error saving staff:', error);
        showToast('Failed to save staff', 'error');
    });
}

// Delete staff
function deleteStaff(staffId) {
    if (!confirm('Are you sure you want to delete this staff member?')) {
        return;
    }
    
    const token = localStorage.getItem('token');
    
    fetch(`/api/security-staff/${staffId}`, {
        method: 'DELETE',
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to delete staff');
        }
        return response.json();
    })
    .then(data => {
        showToast('Staff deleted successfully', 'success');
        loadSecurityStaff();
    })
    .catch(error => {
        console.error('Error deleting staff:', error);
        showToast('Failed to delete staff', 'error');
    });
}

// Search staff
function searchStaff(query) {
    if (!query.trim()) {
        loadSecurityStaff();
        return;
    }
    
    const token = localStorage.getItem('token');
    const tableBody = document.getElementById('staff-table-body');
    
    tableBody.innerHTML = '<tr><td colspan="5" class="text-center">Searching...</td></tr>';
    
    fetch(`/api/security-staff/search?q=${encodeURIComponent(query)}`, {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Search failed');
        }
        return response.json();
    })
    .then(data => {
        if (data.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="5" class="text-center">No matching staff found</td></tr>';
            return;
        }
        
        // Re-render with search results (same rendering code as loadSecurityStaff)
        tableBody.innerHTML = '';
        data.forEach(staff => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${staff.staff_id}</td>
                <td>${staff.name}</td>
                <td>${staff.role}</td>
                <td>${staff.contact_number || 'N/A'}</td>
                <td>
                    <button class="btn edit-btn" data-id="${staff.staff_id}">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button class="btn delete-btn" data-id="${staff.staff_id}">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </td>
            `;
            tableBody.appendChild(row);
        });
        
        // Re-attach event listeners
        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                editStaff(this.getAttribute('data-id'));
            });
        });
        
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                deleteStaff(this.getAttribute('data-id'));
            });
        });
    })
    .catch(error => {
        console.error('Error searching staff:', error);
        tableBody.innerHTML = '<tr><td colspan="5" class="text-center">Search failed</td></tr>';
        showToast('Search failed', 'error');
    });
}
