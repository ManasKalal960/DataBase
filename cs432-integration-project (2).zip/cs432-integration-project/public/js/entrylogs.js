document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const addEntryLogBtn = document.getElementById('add-entry-log-btn');
    const entryLogForm = document.getElementById('entry-log-form');
    const entryLogModal = document.getElementById('entry-log-modal');
    const closeModal = entryLogModal.querySelector('.close-modal');
    const cancelBtn = document.getElementById('cancel-entry-log');
    const filterBtn = document.getElementById('entry-filter-btn');
    
    // Event listeners
    if (addEntryLogBtn) {
        addEntryLogBtn.addEventListener('click', function() {
            showEntryLogModal();
        });
    }
    
    if (closeModal) {
        closeModal.addEventListener('click', function() {
            entryLogModal.style.display = 'none';
        });
    }
    
    if (cancelBtn) {
        cancelBtn.addEventListener('click', function() {
            entryLogModal.style.display = 'none';
        });
    }
    
    if (entryLogForm) {
        entryLogForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveEntryLog();
        });
    }
    
    if (filterBtn) {
        filterBtn.addEventListener('click', function() {
            const from = document.getElementById('entry-date-from').value;
            const to = document.getElementById('entry-date-to').value;
            loadEntryLogs(from, to);
        });
    }
});

// Load entry logs
function loadEntryLogs(fromDate = null, toDate = null) {
    const token = localStorage.getItem('token');
    const tableBody = document.getElementById('entry-logs-table-body');
    
    tableBody.innerHTML = '<tr><td colspan="5" class="text-center">Loading...</td></tr>';
    
    let url = '/api/entry-logs';
    if (fromDate || toDate) {
        url += '?';
        if (fromDate) url += `from=${fromDate}`;
        if (fromDate && toDate) url += '&';
        if (toDate) url += `to=${toDate}`;
    }
    
    fetch(url, {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to fetch entry logs');
        }
        return response.json();
    })
    .then(data => {
        if (data.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="5" class="text-center">No entry logs found</td></tr>';
            return;
        }
        
        tableBody.innerHTML = '';
        data.forEach(entry => {
            const entryTime = new Date(entry.entry_time).toLocaleString();
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${entry.log_id}</td>
                <td>${entry.visitor_name}</td>
                <td>${entry.location}</td>
                <td>${entryTime}</td>
                <td>
                    <button class="btn delete-btn" data-id="${entry.log_id}">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </td>
            `;
            tableBody.appendChild(row);
        });
        
        // Add event listeners to delete buttons
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                deleteEntryLog(this.getAttribute('data-id'));
            });
        });
    })
    .catch(error => {
        console.error('Error loading entry logs:', error);
        tableBody.innerHTML = '<tr><td colspan="5" class="text-center">Error loading entry logs</td></tr>';
        showToast('Failed to load entry logs', 'error');
    });
}

// Load visitors for select dropdown
function loadVisitorsForSelect() {
    const token = localStorage.getItem('token');
    const visitorSelect = document.getElementById('entry-visitor');
    
    fetch('/api/visitors', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => response.json())
    .then(data => {
        // Filter out visitors who have already exited
        const activeVisitors = data.filter(visitor => !visitor.exit_time);
        
        visitorSelect.innerHTML = '<option value="">Select visitor</option>';
        
        activeVisitors.forEach(visitor => {
            const option = document.createElement('option');
            option.value = visitor.visitor_id;
            option.textContent = visitor.name;
            visitorSelect.appendChild(option);
        });
    })
    .catch(error => {
        console.error('Error loading visitors:', error);
        showToast('Failed to load visitor list', 'error');
    });
}

// Load gates for select dropdown
function loadGatesForSelect() {
    const token = localStorage.getItem('token');
    const gateSelect = document.getElementById('entry-gate');
    
    fetch('/api/gates', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => response.json())
    .then(data => {
        // Filter to only show open gates
        const openGates = data.filter(gate => gate.status === 'Open');
        
        gateSelect.innerHTML = '<option value="">Select gate</option>';
        
        openGates.forEach(gate => {
            const option = document.createElement('option');
            option.value = gate.gate_id;
            option.textContent = gate.location;
            gateSelect.appendChild(option);
        });
    })
    .catch(error => {
        console.error('Error loading gates:', error);
        showToast('Failed to load gate list', 'error');
    });
}

// Show entry log modal
function showEntryLogModal() {
    document.getElementById('entry-log-form').reset();
    loadVisitorsForSelect();
    loadGatesForSelect();
    document.getElementById('entry-log-modal').style.display = 'block';
}

// Save entry log
function saveEntryLog() {
    const token = localStorage.getItem('token');
    
    const entryData = {
        visitor_id: document.getElementById('entry-visitor').value,
        gate_id: document.getElementById('entry-gate').value
    };
    
    fetch('/api/entry-logs', {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(entryData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to save entry log');
        }
        return response.json();
    })
    .then(data => {
        document.getElementById('entry-log-modal').style.display = 'none';
        showToast('Entry log added successfully', 'success');
        loadEntryLogs();
    })
    .catch(error => {
        console.error('Error saving entry log:', error);
        showToast('Failed to add entry log', 'error');
    });
}

// Delete entry log
function deleteEntryLog(logId) {
    if (!confirm('Are you sure you want to delete this entry log?')) {
        return;
    }
    
    const token = localStorage.getItem('token');
    
    fetch(`/api/entry-logs/${logId}`, {
        method: 'DELETE',
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to delete entry log');
        }
        return response.json();
    })
    .then(data => {
        showToast('Entry log deleted successfully', 'success');
        loadEntryLogs();
    })
    .catch(error => {
        console.error('Error deleting entry log:', error);
        showToast('Failed to delete entry log', 'error');
    });
}
