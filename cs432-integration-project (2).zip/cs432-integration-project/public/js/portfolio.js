document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const addPortfolioBtn = document.getElementById('add-portfolio-btn');
    const portfolioForm = document.getElementById('portfolio-form');
    const portfolioModal = document.getElementById('portfolio-modal');
    const portfolioViewModal = document.getElementById('portfolio-view-modal');
    const closeModals = document.querySelectorAll('.close-modal');
    const cancelBtn = document.getElementById('cancel-portfolio');
    const searchInput = document.getElementById('portfolio-search');
    const searchBtn = document.getElementById('portfolio-search-btn');
    
    // Event listeners
    if (addPortfolioBtn) {
        addPortfolioBtn.addEventListener('click', function() {
            showPortfolioModal();
        });
    }
    
    closeModals.forEach(closeBtn => {
        closeBtn.addEventListener('click', function() {
            document.querySelectorAll('.modal').forEach(modal => {
                modal.style.display = 'none';
            });
        });
    });
    
    if (cancelBtn) {
        cancelBtn.addEventListener('click', function() {
            portfolioModal.style.display = 'none';
        });
    }
    
    if (portfolioForm) {
        portfolioForm.addEventListener('submit', function(e) {
            e.preventDefault();
            savePortfolio();
        });
    }
    
    if (searchBtn) {
        searchBtn.addEventListener('click', function() {
            searchPortfolios(searchInput.value);
        });
    }
    
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchPortfolios(this.value);
            }
        });
    }
});

// Load portfolios
function loadPortfolios() {
    const token = localStorage.getItem('token');
    const container = document.getElementById('portfolios-container');
    
    container.innerHTML = '<div class="loading">Loading portfolios...</div>';
    
    fetch('/api/portfolios', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to fetch portfolios');
        }
        return response.json();
    })
    .then(data => {
        if (data.length === 0) {
            container.innerHTML = '<div class="no-data">No portfolios found</div>';
            return;
        }
        
        container.innerHTML = '';
        data.forEach(portfolio => {
            const card = document.createElement('div');
            card.className = 'portfolio-card';
            
            // Parse skills if they exist
            let skillsHtml = '';
            if (portfolio.skills) {
                try {
                    const skills = JSON.parse(portfolio.skills);
                    skillsHtml = skills.map(skill => 
                        `<span class="skill-tag">${skill}</span>`
                    ).join('');
                } catch (e) {
                    skillsHtml = portfolio.skills;
                }
            }
            
            card.innerHTML = `
                <h3>${portfolio.name}</h3>
                <p>${portfolio.email}</p>
                <div class="portfolio-preview">
                    ${portfolio.bio.substring(0, 100)}${portfolio.bio.length > 100 ? '...' : ''}
                </div>
                <div class="skills-container">
                    ${skillsHtml || 'No skills listed'}
                </div>
                <div class="portfolio-actions">
                    <button class="btn view-portfolio-btn" data-id="${portfolio.member_id}">
                        <i class="fas fa-eye"></i> View
                    </button>
                </div>
            `;
            container.appendChild(card);
        });
        
        // Add event listeners to view buttons
        document.querySelectorAll('.view-portfolio-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                viewPortfolio(this.getAttribute('data-id'));
            });
        });
    })
    .catch(error => {
        console.error('Error loading portfolios:', error);
        container.innerHTML = '<div class="error">Error loading portfolios</div>';
        showToast('Failed to load portfolios', 'error');
    });
}

// Load college members for select dropdown
function loadPortfolioMembers() {
    const token = localStorage.getItem('token');
    const memberSelect = document.getElementById('portfolio-member');
    
    fetch('/api/collage-members', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => response.json())
    .then(data => {
        memberSelect.innerHTML = '<option value="">Select member</option>';
        
        data.forEach(member => {
            const option = document.createElement('option');
            option.value = member.member_id;
            option.textContent = `${member.name} (ID: ${member.member_id})`;
            memberSelect.appendChild(option);
        });
    })
    .catch(error => {
        console.error('Error loading members:', error);
        showToast('Failed to load member list', 'error');
    });
}

// Show portfolio modal for adding
function showPortfolioModal() {
    document.getElementById('portfolio-modal-title').textContent = 'Create Portfolio';
    document.getElementById('portfolio-form').reset();
    loadPortfolioMembers();
    document.getElementById('portfolio-modal').style.display = 'block';
}

// Save portfolio
function savePortfolio() {
    const token = localStorage.getItem('token');
    
    // Parse skills into array
    const skillsInput = document.getElementById('portfolio-skills').value;
    const skills = skillsInput.split(',')
        .map(skill => skill.trim())
        .filter(skill => skill.length > 0);
    
    const portfolioData = {
        member_id: document.getElementById('portfolio-member').value,
        bio: document.getElementById('portfolio-bio').value,
        skills: skills.length ? skills : null
    };
    
    fetch('/api/portfolio', {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(portfolioData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to save portfolio');
        }
        return response.json();
    })
    .then(data => {
        document.getElementById('portfolio-modal').style.display = 'none';
        showToast('Portfolio created successfully', 'success');
        loadPortfolios();
    })
    .catch(error => {
        console.error('Error saving portfolio:', error);
        showToast('Failed to create portfolio', 'error');
    });
}

// View portfolio
function viewPortfolio(memberId) {
    const token = localStorage.getItem('token');
    
    fetch(`/api/portfolio/${memberId}`, {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to fetch portfolio details');
        }
        return response.json();
    })
    .then(portfolio => {
        document.getElementById('portfolio-name').textContent = portfolio.name;
        document.getElementById('portfolio-email').textContent = portfolio.email;
        document.getElementById('portfolio-view-bio').textContent = portfolio.bio;
        
        // Parse and display skills
        const skillsContainer = document.getElementById('portfolio-view-skills');
        skillsContainer.innerHTML = '';
        
        if (portfolio.skills) {
            try {
                const skills = JSON.parse(portfolio.skills);
                skills.forEach(skill => {
                    const skillTag = document.createElement('span');
                    skillTag.className = 'skill-tag';
                    skillTag.textContent = skill;
                    skillsContainer.appendChild(skillTag);
                });
            } catch (e) {
                skillsContainer.textContent = portfolio.skills;
            }
        } else {
            skillsContainer.textContent = 'No skills listed';
        }
        
        document.getElementById('portfolio-view-modal').style.display = 'block';
    })
    .catch(error => {
        console.error('Error fetching portfolio details:', error);
        showToast('Failed to load portfolio details', 'error');
    });
}

// Search portfolios
function searchPortfolios(query) {
    if (!query.trim()) {
        loadPortfolios();
        return;
    }
    
    const token = localStorage.getItem('token');
    const container = document.getElementById('portfolios-container');
    
    container.innerHTML = '<div class="loading">Searching...</div>';
    
    fetch(`/api/portfolios/search?query=${encodeURIComponent(query)}`, {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Search failed');
        }
        return response.json();
    })
    .then(data => {
        if (data.length === 0) {
            container.innerHTML = '<div class="no-data">No matching portfolios found</div>';
            return;
        }
        
        // Re-render with search results (same as loadPortfolios rendering)
        container.innerHTML = '';
        data.forEach(portfolio => {
            // Same rendering code as in loadPortfolios
            const card = document.createElement('div');
            card.className = 'portfolio-card';
            
            // Parse skills if they exist
            let skillsHtml = '';
            if (portfolio.skills) {
                try {
                    const skills = JSON.parse(portfolio.skills);
                    skillsHtml = skills.map(skill => 
                        `<span class="skill-tag">${skill}</span>`
                    ).join('');
                } catch (e) {
                    skillsHtml = portfolio.skills;
                }
            }
            
            card.innerHTML = `
                <h3>${portfolio.name}</h3>
                <p>${portfolio.email}</p>
                <div class="portfolio-preview">
                    ${portfolio.bio.substring(0, 100)}${portfolio.bio.length > 100 ? '...' : ''}
                </div>
                <div class="skills-container">
                    ${skillsHtml || 'No skills listed'}
                </div>
                <div class="portfolio-actions">
                    <button class="btn view-portfolio-btn" data-id="${portfolio.member_id}">
                        <i class="fas fa-eye"></i> View
                    </button>
                </div>
            `;
            container.appendChild(card);
        });
        
        // Re-attach event listeners
        document.querySelectorAll('.view-portfolio-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                viewPortfolio(this.getAttribute('data-id'));
            });
        });
    })
    .catch(error => {
        console.error('Error searching portfolios:', error);
        container.innerHTML = '<div class="error">Search failed</div>';
        showToast('Search failed', 'error');
    });
}
