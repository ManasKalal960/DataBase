document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const addMemberBtn = document.getElementById('add-member-btn');
    const memberForm = document.getElementById('member-form');
    const memberModal = document.getElementById('member-modal');
    const closeModal = memberModal.querySelector('.close-modal');
    const cancelBtn = document.getElementById('cancel-member');
    
    // Event listeners
    if (addMemberBtn) {
        addMemberBtn.addEventListener('click', function() {
            showMemberModal();
        });
    }
    
    if (closeModal) {
        closeModal.addEventListener('click', function() {
            memberModal.style.display = 'none';
        });
    }
    
    if (cancelBtn) {
        cancelBtn.addEventListener('click', function() {
            memberModal.style.display = 'none';
        });
    }
    
    if (memberForm) {
        memberForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveMember();
        });
    }
});

// Load members from API
function loadMembers() {
    const token = localStorage.getItem('token');
    const tableBody = document.getElementById('members-table-body');
    
    tableBody.innerHTML = '<tr><td colspan="4" class="text-center">Loading...</td></tr>';
    
    fetch('/api/members', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to fetch members');
        }
        return response.json();
    })
    .then(data => {
        if (data.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="4" class="text-center">No members found</td></tr>';
            return;
        }
        
        tableBody.innerHTML = '';
        data.forEach(member => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${member.ID}</td>
                <td>${member.UserName}</td>
                <td>${member.emailID}</td>
                <td>
                    <button class="btn delete-btn" data-id="${member.ID}">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </td>
            `;
            tableBody.appendChild(row);
        });
        
        // Add event listeners to delete buttons
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const memberId = this.getAttribute('data-id');
                if (confirm('Are you sure you want to delete this member?')) {
                    deleteMember(memberId);
                }
            });
        });
    })
    .catch(error => {
        console.error('Error loading members:', error);
        tableBody.innerHTML = '<tr><td colspan="4" class="text-center">Error loading members</td></tr>';
    });
}

// Show member modal
function showMemberModal() {
    document.getElementById('member-modal-title').textContent = 'Add Member';
    document.getElementById('member-form').reset();
    document.getElementById('member-modal').style.display = 'block';
}

// Save member
function saveMember() {
    const token = localStorage.getItem('token');
    const memberData = {
        name: document.getElementById('member-name').value,
        email: document.getElementById('member-email').value,
        dob: document.getElementById('member-dob').value
    };
    
    fetch('/api/members', {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(memberData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to create member');
        }
        return response.json();
    })
    .then(data => {
        document.getElementById('member-modal').style.display = 'none';
        showToast('Member added successfully', 'success');
        loadMembers();
    })
    .catch(error => {
        console.error('Error saving member:', error);
        showToast('Failed to add member', 'error');
    });
}

// Delete member
function deleteMember(memberId) {
    const token = localStorage.getItem('token');
    
    fetch(`/api/members/${memberId}`, {
        method: 'DELETE',
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to delete member');
        }
        return response.json();
    })
    .then(data => {
        showToast(data.message, 'success');
        loadMembers();
    })
    .catch(error => {
        console.error('Error deleting member:', error);
        showToast('Failed to delete member', 'error');
    });
}

// Show toast notification
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    
    document.getElementById('toast-container').appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 5000);
}
