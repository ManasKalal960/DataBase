document.addEventListener('DOMContentLoaded', function() {
    // Check authentication
    const token = localStorage.getItem('token');
    if (!token) {
        // Redirect to login instead of reloading
        document.getElementById('auth-container').style.display = 'block';
        document.getElementById('app-container').style.display = 'none';
        return;
    }
    
    // Initialize user info in the sidebar
    initUserInfo();
    
    // Setup navigation
    setupNavigation();
    
    // Load dashboard data
    loadDashboardData();
    
    // Setup modals (fix the issue with closing modals)
    setupModals();
});

// Initialize user info in the sidebar
function initUserInfo() {
    try {
        const user = JSON.parse(localStorage.getItem('user'));
        if (user) {
            // Set user name
            const userNameElement = document.getElementById('user-name');
            if (userNameElement) userNameElement.textContent = user.id;
            
            // Set user role
            const userRoleElement = document.querySelector('#user-role span');
            if (userRoleElement) userRoleElement.textContent = user.role;
            
            // Handle role-based UI elements
            if (user.role !== 'admin') {
                document.querySelectorAll('.admin-only').forEach(el => {
                    el.style.display = 'none';
                });
            }
        }
    } catch (error) {
        console.error('Error initializing user info:', error);
    }
}

// Setup sidebar navigation with robust event handling
function setupNavigation() {
    try {
        // Get all navigation items
        const navItems = document.querySelectorAll('.nav-item');
        if (navItems.length === 0) {
            console.warn('No navigation items found with .nav-item class');
            return;
        }
        
        console.log(`Found ${navItems.length} navigation items`);
        
        // Remove any existing event listeners to prevent duplicates
        navItems.forEach(item => {
            const newItem = item.cloneNode(true);
            item.parentNode.replaceChild(newItem, item);
        });
        
        // Get the fresh items after replacement
        const freshNavItems = document.querySelectorAll('.nav-item');
        
        // Add click event listener to each navigation item
        freshNavItems.forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault(); // Prevent default link behavior
                
                // Get section to show
                const section = this.getAttribute('data-section');
                if (!section) {
                    console.warn('Navigation item clicked but no data-section attribute found', this);
                    return;
                }
                
                console.log(`Navigation clicked: ${section}`);
                
                // Update active nav item
                freshNavItems.forEach(i => i.classList.remove('active'));
                this.classList.add('active');
                
                // Show corresponding section
                const sections = document.querySelectorAll('.content-section');
                sections.forEach(s => s.classList.remove('active'));
                
                const targetSection = document.getElementById(`${section}-section`);
                if (targetSection) {
                    targetSection.classList.add('active');
                } else {
                    console.warn(`Section element #${section}-section not found`);
                }
                
                // Update section title
                const titleElement = document.getElementById('section-title');
                if (titleElement) {
                    const linkElement = this.querySelector('a');
                    titleElement.textContent = linkElement ? linkElement.textContent.trim() : this.textContent.trim();
                }
                
                // Load section data if needed
                loadSectionData(section);
            });
        });
        
        // Activate the first nav item by default if none is active
        if (!document.querySelector('.nav-item.active') && freshNavItems.length > 0) {
            freshNavItems[0].click();
        }
        
    } catch (error) {
        console.error('Error setting up navigation:', error);
    }
}

// Load section-specific data
function loadSectionData(section) {
    try {
        switch(section) {
            case 'dashboard':
                if (typeof loadDashboardData === 'function') loadDashboardData();
                break;
            case 'members':
                if (typeof loadMembers === 'function') loadMembers();
                break;
            case 'college-members':
                if (typeof loadCollegeMembers === 'function') loadCollegeMembers();
                break;
            case 'vehicles':
                if (typeof loadVehicles === 'function') loadVehicles();
                break;
            case 'visitors':
                if (typeof loadVisitors === 'function') loadVisitors();
                break;
            case 'gates':
                if (typeof loadGates === 'function') loadGates();
                break;
            case 'entry-logs':
                if (typeof loadEntryLogs === 'function') loadEntryLogs();
                break;
            case 'exit-logs':
                if (typeof loadExitLogs === 'function') loadExitLogs();
                break;
            case 'security-staff':
                if (typeof loadSecurityStaff === 'function') loadSecurityStaff();
                break;
            case 'permissions':
                if (typeof loadPermissions === 'function') loadPermissions();
                break;
            case 'alerts':
                if (typeof loadAlerts === 'function') loadAlerts();
                break;
            case 'parking':
                if (typeof loadParkingLogs === 'function') loadParkingLogs();
                break;
            case 'portfolio':
                if (typeof loadPortfolio === 'function') loadPortfolio();
                break;
            default:
                console.warn(`No data loader found for section: ${section}`);
        }
    } catch (error) {
        console.error(`Error loading data for section ${section}:`, error);
    }
}

// Load dashboard data (counts and recent activity)
function loadDashboardData() {
    const token = localStorage.getItem('token');
    if (!token) return;
    
    const endpoints = [
        { url: '/api/collage-members/count', elementId: 'member-count', name: 'member' },
        { url: '/api/vehicles/count', elementId: 'vehicle-count', name: 'vehicle' },
        { url: '/api/visitors/active/count', elementId: 'visitor-count', name: 'visitor' },
        { url: '/api/alerts/count', elementId: 'alert-count', name: 'alert' }
    ];
    
    // Fetch all counts
    endpoints.forEach(endpoint => {
        fetch(endpoint.url, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            const element = document.getElementById(endpoint.elementId);
            if (element) {
                element.textContent = data.count || 0;
            }
        })
        .catch(error => {
            console.error(`Error fetching ${endpoint.name} count:`, error);
            // Set to 0 in case of error
            const element = document.getElementById(endpoint.elementId);
            if (element) {
                element.textContent = '0';
            }
        });
    });
    
    // Fetch recent activity (entry logs, alerts, etc.)
    fetch('/api/entry-logs?limit=5', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        const activityList = document.getElementById('activity-list');
        if (!activityList) return;
        
        activityList.innerHTML = '';
        
        if (data.length > 0) {
            data.forEach(entry => {
                const li = document.createElement('li');
                li.textContent = `${entry.visitor_name} entered through ${entry.location} at ${new Date(entry.entry_time).toLocaleString()}`;
                activityList.appendChild(li);
            });
        } else {
            const li = document.createElement('li');
            li.textContent = 'No recent activity';
            activityList.appendChild(li);
        }
    })
    .catch(error => {
        console.error('Error fetching recent activity:', error);
        const activityList = document.getElementById('activity-list');
        if (activityList) {
            activityList.innerHTML = '<li>Error loading recent activity</li>';
        }
    });
}

// Fix modal closing issue
function setupModals() {
    // Get all close buttons for modals
    const closeButtons = document.querySelectorAll('.modal .close-modal');
    
    // Add event listener to each close button
    closeButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            // Find the parent modal and hide only that one
            const modal = this.closest('.modal');
            if (modal) {
                modal.style.display = 'none';
            }
            
            // Prevent event from bubbling up
            e.stopPropagation();
        });
    });
    
    // Close modal when clicking outside the content
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.style.display = 'none';
            }
        });
    });
    
    // Global function to show a specific modal
    window.showModal = function(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.style.display = 'block';
        } else {
            console.warn(`Modal #${modalId} not found`);
        }
    };
}
