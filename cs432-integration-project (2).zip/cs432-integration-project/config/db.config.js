require('dotenv').config();
const mysql = require('mysql2/promise');

module.exports = {
  cimsPool: mysql.createPool({
    host: process.env.CIMS_DB_HOST,
    user: process.env.CIMS_DB_USER,
    password: process.env.CIMS_DB_PASSWORD,
    database: 'cs432cims',
    waitForConnections: true,
    connectionLimit: 10
  }),
  
  projectPool: mysql.createPool({
    host: process.env.PROJECT_DB_HOST,
    user: process.env.PROJECT_DB_USER,
    password: process.env.PROJECT_DB_PASSWORD,
    database: 'cs432g15',
    waitForConnections: true,
    connectionLimit: 10
  })
};
