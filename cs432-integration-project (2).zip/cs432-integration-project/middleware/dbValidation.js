const { cimsPool } = require('../config/db.config');

exports.verifyCIMSMember = async (req, res, next) => {
  const memberId = req.body.member_id || req.params.id;
  
  try {
    const [rows] = await cimsPool.query(
      `SELECT ID FROM members WHERE ID = ?`, 
      [memberId]
    );
    
    if (!rows.length) {
      return res.status(404).json({ error: "Member not found in CIMS database" });
    }
    next();
  } catch (error) {
    res.status(500).json({ error: "Database verification failed" });
  }
};
