const logger = require('../utils/logger');

exports.authorize = (...allowedRoles) => {
  return (req, res, next) => {
    // Check if user has required role
    if (!req.user || !allowedRoles.includes(req.user.role)) {
      logger.warn(`Authorization failed: User ${req.user?.userid} with role ${req.user?.role} attempted to access restricted endpoint ${req.method} ${req.path}`);
      return res.status(403).json({ error: "Unauthorized access" });
    }
    
    logger.info(`User ${req.user.userid} with role ${req.user.role} authorized for ${req.method} ${req.path}`);
    next();
  };
};
