const jwt = require('jsonwebtoken');
const logger = require('../utils/logger');

exports.authenticate = (req, res, next) => {
  // Get token from multiple possible sources
  let token = null;
  
  // Check cookie first
  if (req.cookies && req.cookies.session_token) {
    token = req.cookies.session_token;
  } 
  // Then check authorization header
  else if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
    token = req.headers.authorization.split(' ')[1];
  }
  
  if (!token) {
    logger.warn(`Authentication failed: No token provided for ${req.method} ${req.path}`);
    return res.status(401).json({ error: "Access denied" });
  }

  try {
    // Verify token with proper error handling
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Attach user info to request object
    req.user = decoded;
    logger.info(`User ${decoded.userid} authenticated for ${req.method} ${req.path}`);
    next();
  } catch (error) {
    // Log detailed error information
    console.error("Token verification error:", error);
    logger.error(`Token verification failed: ${error.message}`);
    
    // Send appropriate error response
    if (error.name === 'TokenExpiredError') {
      res.status(401).json({ error: "Token expired" });
    } else {
      res.status(400).json({ error: "Invalid token" });
    }
  }
};

exports.authorize = (...roles) => {
    return (req, res, next) => {
      if (!req.user || !roles.includes(req.user.role)) {
        logger.warn(`Authorization failed: User ${req.user?.userid} with role ${req.user?.role} attempted to access restricted endpoint`);
        return res.status(403).json({ error: "Unauthorized access" });
      }
      logger.info(`User ${req.user.userid} authorized with role: ${req.user.role}`);
      next();
    };
  };
