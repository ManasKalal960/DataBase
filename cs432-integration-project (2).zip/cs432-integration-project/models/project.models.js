const { projectPool, cimsPool } = require('../config/db.config');
const logger = require('../utils/logger');

// ================== Collage Member ==================
exports.createCollageMember = async (memberData) => {
  const [result] = await projectPool.execute(
    `INSERT INTO CollageMember (name, email, date_joined, status)
     VALUES (?, ?, CURDATE(), ?)`,
    [memberData.name, memberData.email, memberData.status || 'Active']
  );
  return result.insertId;
};

exports.getCollageMemberById = async (memberId) => {
  const [rows] = await projectPool.execute(
    'SELECT * FROM CollageMember WHERE member_id = ?',
    [memberId]
  );
  return rows[0];
};

exports.updateCollageMember = async (memberId, updateData) => {
  await projectPool.execute(
    `UPDATE CollageMember 
     SET name = ?, email = ?, status = ?
     WHERE member_id = ?`,
    [updateData.name, updateData.email, updateData.status, memberId]
  );
};

exports.deleteCollageMember = async (memberId) => {
  await projectPool.execute(
    'DELETE FROM CollageMember WHERE member_id = ?',
    [memberId]
  );
};

// ================== Vehicle ==================
exports.addVehicle = async (vehicleData) => {
  const [result] = await projectPool.execute(
    `INSERT INTO Vehicle 
     (license_plate, member_id, vehicle_type, brand, model, color)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [
      vehicleData.license_plate,
      vehicleData.member_id,
      vehicleData.vehicle_type,
      vehicleData.brand,
      vehicleData.model,
      vehicleData.color
    ]
  );
  return result.insertId;
};

exports.getVehicleById = async (vehicleId) => {
  const [rows] = await projectPool.execute(
    'SELECT * FROM Vehicle WHERE vehicle_id = ?',
    [vehicleId]
  );
  return rows[0];
};

exports.deleteVehicle = async (vehicleId) => {
  await projectPool.execute(
    'DELETE FROM Vehicle WHERE vehicle_id = ?',
    [vehicleId]
  );
};

// ================== Portfolio ==================
exports.createPortfolio = async (portfolioData) => {
  const [result] = await projectPool.execute(
    `INSERT INTO Portfolio 
     (member_id, bio, skills)
     VALUES (?, ?, ?)`,
    [portfolioData.member_id, portfolioData.bio, portfolioData.skills]
  );
  return result.insertId;
};

exports.getPortfolio = async (memberId) => {
  const [rows] = await projectPool.execute(
    `SELECT c.name, c.email, p.bio, p.skills 
     FROM Portfolio p
     JOIN CollageMember c ON p.member_id = c.member_id
     WHERE p.member_id = ?`,
    [memberId]
  );
  return rows[0];
};


// ================== Visitor ==================
exports.createVisitor = async (visitorData) => {
  const [result] = await projectPool.execute(
    `INSERT INTO Visitor (name, purpose, entry_time)
     VALUES (?, ?, CURRENT_TIMESTAMP)`,
    [visitorData.name, visitorData.purpose || 'General Visit']
  );
  return result.insertId;
};

exports.getVisitorById = async (visitorId) => {
  const [rows] = await projectPool.execute(
    `SELECT * FROM Visitor WHERE visitor_id = ?`,
    [visitorId]
  );
  return rows[0];
};

exports.logVisitorExit = async (visitorId) => {
  await projectPool.execute(
    `UPDATE Visitor 
     SET exit_time = CURRENT_TIMESTAMP 
     WHERE visitor_id = ?`,
    [visitorId]
  );
};

// ================== Gate ==================
exports.getAllGates = async () => {
  const [rows] = await projectPool.execute(
    `SELECT * FROM Gate`
  );
  return rows;
};

exports.updateGateStatus = async (gateId, status) => {
  await projectPool.execute(
    `UPDATE Gate SET status = ? WHERE gate_id = ?`,
    [status, gateId]
  );
};

// ================== EntryLog ==================
exports.createEntryLog = async (visitorId, gateId) => {
  const [result] = await projectPool.execute(
    `INSERT INTO EntryLog (visitor_id, gate_id)
     VALUES (?, ?)`,
    [visitorId, gateId]
  );
  return result.insertId;
};

exports.getRecentEntries = async (limit = 50) => {
  const [rows] = await projectPool.execute(
    `SELECT e.*, v.name AS visitor_name, g.location 
     FROM EntryLog e
     JOIN Visitor v ON e.visitor_id = v.visitor_id
     JOIN Gate g ON e.gate_id = g.gate_id
     ORDER BY entry_time DESC
     LIMIT ?`,
    [limit]
  );
  return rows;
};



// ================== ExitLog ==================
exports.createExitLog = async (visitorId, gateId) => {
  const [result] = await projectPool.execute(
    `INSERT INTO ExitLog (visitor_id, gate_id, exit_time)
     VALUES (?, ?, CURRENT_TIMESTAMP)`,
    [visitorId, gateId]
  );
  return result.insertId;
};

exports.getExitLogs = async () => {
  const [rows] = await projectPool.execute(`
    SELECT e.*, v.name AS visitor_name, g.location 
    FROM ExitLog e
    JOIN Visitor v ON e.visitor_id = v.visitor_id
    JOIN Gate g ON e.gate_id = g.gate_id
  `);
  return rows;
};

// ================== SecurityStaff ==================
exports.addSecurityStaff = async (staffData) => {
  const [result] = await projectPool.execute(
    `INSERT INTO SecurityStaff (name, role, contact_number)
     VALUES (?, ?, ?)`,
    [staffData.name, staffData.role, staffData.contact_number]
  );
  return result.insertId;
};

exports.getSecurityStaff = async () => {
  const [rows] = await projectPool.execute('SELECT * FROM SecurityStaff');
  return rows;
};

// ================== AccessPermission ==================
exports.createAccessPermission = async (permissionData) => {
  const [result] = await projectPool.execute(
    `INSERT INTO AccessPermission (role, resource, action)
     VALUES (?, ?, ?)`,
    [permissionData.role, permissionData.resource, permissionData.action]
  );
  return result.insertId;
};

exports.getPermissionsByRole = async (role) => {
  const [rows] = await projectPool.execute(
    'SELECT * FROM AccessPermission WHERE role = ?',
    [role]
  );
  return rows;
};


// ================== Alerts ==================
exports.createAlert = async (alertData) => {
  const [result] = await projectPool.execute(
    `INSERT INTO Alerts (description, severity)
     VALUES (?, ?)`,
    [alertData.description, alertData.severity || 'Medium']
  );
  return result.insertId;
};

exports.getAlerts = async (limit = 50) => {
  const [rows] = await projectPool.execute(
    `SELECT * FROM Alerts 
     ORDER BY timestamp DESC
     LIMIT ?`,
    [limit]
  );
  return rows;
};

exports.updateAlertStatus = async (alertId) => {
  await projectPool.execute(
    `UPDATE Alerts SET resolved = TRUE WHERE alert_id = ?`,
    [alertId]
  );
};

exports.deleteAlert = async (alertId) => {
  await projectPool.execute(
    `DELETE FROM Alerts WHERE alert_id = ?`,
    [alertId]
  );
};

// ================== ParkingLog ==================
exports.createParkingEntry = async (vehicleId) => {
  const [result] = await projectPool.execute(
    `INSERT INTO ParkingLog (vehicle_id)
     VALUES (?)`,
    [vehicleId]
  );
  return result.insertId;
};

exports.updateParkingExit = async (logId) => {
  await projectPool.execute(
    `UPDATE ParkingLog 
     SET exit_time = CURRENT_TIMESTAMP 
     WHERE log_id = ?`,
    [logId]
  );
};

exports.getParkingLogs = async () => {
  const [rows] = await projectPool.execute(`
    SELECT p.*, v.license_plate, v.vehicle_type, 
           c.name AS owner_name
    FROM ParkingLog p
    JOIN Vehicle v ON p.vehicle_id = v.vehicle_id
    JOIN CollageMember c ON v.member_id = c.member_id
  `);
  return rows;
};
