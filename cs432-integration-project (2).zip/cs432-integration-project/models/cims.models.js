const { cimsPool } = require('../config/db.config');
const logger = require('../utils/logger');

exports.createMember = async (memberData) => {
    const connection = await cimsPool.getConnection();
    console.log("Database connection established"); // Log connection status
  
    try {
      await connection.beginTransaction();
  
      // Insert into members table
      const [memberResult] = await connection.execute(
        `INSERT INTO members (UserName, emailID, DoB)
         VALUES (?, ?, ?)`,
        [memberData.name, memberData.email, memberData.dob]
      );
      console.log("Insert into members table result:", memberResult);
  
      const memberId = memberResult.insertId;
  
      // Create login entry
      await connection.execute(
        `INSERT INTO Login (MemberID, Password, Role)
         VALUES (?, ?, ?)`,
        [memberId, 'defaultPassword', 'user']
      );
      console.log("Insert into Login table successful");
  
      // Add to group mapping
      await connection.execute(
        `INSERT INTO MemberGroupMapping (MemberID, GroupID)
         VALUES (?, ?)`,
        [memberId, 15] // Group 15
      );
      console.log("Insert into MemberGroupMapping table successful");
  
      await connection.commit();
      return memberId;
    } catch (error) {
      await connection.rollback();
      console.error("Error during transaction:", error);
      throw error;
    } finally {
      connection.release();
    }
  };
  

exports.deleteMember = async (memberId) => {
  const connection = await cimsPool.getConnection();
  try {
    await connection.beginTransaction();
    
    // Check if member is in other groups
    const [groupRows] = await connection.execute(
      'SELECT * FROM MemberGroupMapping WHERE MemberID = ?',
      [memberId]
    );
    
    if (groupRows.length > 1) {
      // Only remove from this group (15)
      await connection.execute(
        'DELETE FROM MemberGroupMapping WHERE MemberID = ? AND GroupID = ?',
        [memberId, 15]
      );
      await connection.commit();
      return 'removed_group';
    } else {
      // Delete complete member data
      await connection.execute('DELETE FROM Login WHERE MemberID = ?', [memberId]);
      await connection.execute('DELETE FROM MemberGroupMapping WHERE MemberID = ?', [memberId]);
      await connection.execute('DELETE FROM members WHERE ID = ?', [memberId]);
      await connection.commit();
      return 'deleted';
    }
  } catch (error) {
    await connection.rollback();
    logger.error(`Member deletion failed: ${error.message}`);
    throw error;
  } finally {
    connection.release();
  }
};
