# Try direct import first
try:
    from database.bplustree import BPlusTree
# Fall back to relative import if that fails
except ImportError:
    from bplustree import BPlusTree

from datetime import datetime

class Table:
    def __init__(self, name):
        self.name = name
        self.index = BPlusTree(order=4)
        self.last_id = 0

class CollageMemberTable(Table):
    def __init__(self):
        super().__init__("CollageMember")
        self.schema = {
            'member_id': {'type': int, 'primary': True},
            'name': {'type': str, 'required': True},
            'email': {'type': str, 'unique': True},
            'date_joined': {'type': datetime},
            'status': {'type': str, 'options': ['Active', 'Inactive']}
        }

class VehicleTable(Table):
    def __init__(self):
        super().__init__("Vehicle")
        self.schema = {
            'vehicle_id': {'type': int, 'primary': True},
            'license_plate': {'type': str, 'unique': True},
            'member_id': {'type': int, 'foreign_key': 'CollageMember'},
            'vehicle_type': {'type': str},
            'registration_date': {'type': datetime}
        }

class VisitorTable(Table):
    def __init__(self):
        super().__init__("Visitor")
        self.schema = {
            'visitor_id': {'type': int, 'primary': True},
            'name': {'type': str, 'required': True},
            'entry_time': {'type': datetime}
        }
