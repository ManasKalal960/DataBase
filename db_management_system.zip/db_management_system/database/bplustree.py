import graphviz

class BPlusTreeNode:
    def __init__(self, is_leaf=False):
        self.keys = []
        self.values = []
        self.children = []
        self.next_leaf = None  # For leaf node linkage
        self.is_leaf = is_leaf

class BPlusTree:
    def __init__(self, order=3):
        self.root = BPlusTreeNode(is_leaf=True)
        self.order = order
        self.min_keys = (order // 2)
        
    def insert(self, key, value):
        if len(self.root.keys) >= (2 * self.order - 1):
            new_root = BPlusTreeNode()
            new_root.children.append(self.root)
            self._split_child(new_root, 0)
            self.root = new_root
        self._insert_non_full(self.root, key, value)
        
    def _insert_non_full(self, node, key, value):
        if node.is_leaf:
            self._insert_into_leaf(node, key, value)
        else:
            index = self._find_child_index(node, key)
            if len(node.children[index].keys) == (2 * self.order - 1):
                self._split_child(node, index)
                if key > node.keys[index]:
                    index += 1
            self._insert_non_full(node.children[index], key, value)
    
    def _insert_into_leaf(self, node, key, value):
        """Insert key-value pair into leaf node in sorted order"""
        index = 0
        while index < len(node.keys) and key > node.keys[index]:
            index += 1
            
        node.keys.insert(index, key)
        node.values.insert(index, value)
    
    def _find_child_index(self, node, key):
        """Find the index of the child node that should contain the key"""
        index = 0
        while index < len(node.keys) and key >= node.keys[index]:
            index += 1
        return index
    
    def _split_child(self, parent, index):
        child = parent.children[index]
        new_node = BPlusTreeNode(is_leaf=child.is_leaf)
        
        mid = len(child.keys) // 2
        split_key = child.keys[mid]
        
        # Handle leaf node split
        if child.is_leaf:
            new_node.keys = child.keys[mid:]
            new_node.values = child.values[mid:]
            child.keys = child.keys[:mid]
            child.values = child.values[:mid]
            new_node.next_leaf = child.next_leaf
            child.next_leaf = new_node
        else:
            new_node.keys = child.keys[mid+1:]
            new_node.children = child.children[mid+1:]
            child.keys = child.keys[:mid]
            child.children = child.children[:mid+1]
        
        parent.keys.insert(index, split_key)
        parent.children.insert(index+1, new_node)
    
    def delete(self, key):
        if not self.root.keys:
            return False
        
        result = self._delete(self.root, key)
        
        # If root is empty and has children, make first child the new root
        if not self.root.keys and self.root.children:
            self.root = self.root.children[0]
            
        return result
            
    def _delete(self, node, key):
        if node.is_leaf:
            if key in node.keys:
                index = node.keys.index(key)
                node.keys.pop(index)
                node.values.pop(index)
                return True
            return False
        
        # Find the index where the key might be
        index = self._find_child_index(node, key)
        
        # If key is in this node
        if index < len(node.keys) and node.keys[index] == key:
            return self._delete_internal(node, key, index)
        else:
            # If the child has less than t keys, fill it
            if len(node.children[index].keys) <= self.min_keys:
                self._fill_child(node, index)
            
            # Recalculate index if child changed
            if index >= len(node.children):
                return self._delete(node.children[index-1], key)
            else:
                return self._delete(node.children[index], key)
    
    def _delete_internal(self, node, key, index):
        # Case 1: If the key is in internal node and its left child has at least t keys
        if len(node.children[index].keys) > self.min_keys:
            # Replace with predecessor
            predecessor = self._get_predecessor(node.children[index])
            node.keys[index] = predecessor
            return self._delete(node.children[index], predecessor)
            
        # Case 2: If right child has at least t keys
        elif len(node.children[index+1].keys) > self.min_keys:
            # Replace with successor
            successor = self._get_successor(node.children[index+1])
            node.keys[index] = successor
            return self._delete(node.children[index+1], successor)
            
        # Case 3: Both children have only t-1 keys, merge them
        else:
            self._merge(node, index)
            return self._delete(node.children[index], key)
    
    def _get_predecessor(self, node):
        """Get rightmost key from the subtree rooted at node"""
        current = node
        while not current.is_leaf:
            current = current.children[-1]
        return current.keys[-1]
    
    def _get_successor(self, node):
        """Get leftmost key from the subtree rooted at node"""
        current = node
        while not current.is_leaf:
            current = current.children[0]
        return current.keys[0]
    
    def _fill_child(self, node, index):
        # If previous child has extra keys
        if index > 0 and len(node.children[index-1].keys) > self.min_keys:
            self._borrow_from_prev(node, index)
        # If next child has extra keys
        elif index < len(node.children)-1 and len(node.children[index+1].keys) > self.min_keys:
            self._borrow_from_next(node, index)
        else:
            # Merge with sibling
            if index < len(node.children)-1:
                self._merge(node, index)
            else:
                self._merge(node, index-1)
    
    def _borrow_from_prev(self, node, index):
        child = node.children[index]
        sibling = node.children[index-1]
        
        # Shift all keys in child right by 1
        child.keys.insert(0, node.keys[index-1])
        
        # Move last key of sibling to parent
        node.keys[index-1] = sibling.keys.pop()
        
        # Handle children if not leaf
        if not child.is_leaf:
            child.children.insert(0, sibling.children.pop())
        else:
            # Move corresponding value for leaf node
            child.values.insert(0, sibling.values.pop())
    
    def _borrow_from_next(self, node, index):
        child = node.children[index]
        sibling = node.children[index+1]
        
        # Move parent key to child
        child.keys.append(node.keys[index])
        
        # Move first key of sibling to parent
        node.keys[index] = sibling.keys.pop(0)
        
        # Handle children if not leaf
        if not sibling.is_leaf:
            child.children.append(sibling.children.pop(0))
        else:
            # Move corresponding value for leaf node
            child.values.append(sibling.values.pop(0))
    
    def _merge(self, node, index):
        child = node.children[index]
        sibling = node.children[index+1]
        
        # Get the key from parent and put in child
        if not child.is_leaf:
            child.keys.append(node.keys[index])
        
        # Add all keys from sibling to child
        child.keys.extend(sibling.keys)
        
        # If not leaf, move children too
        if not child.is_leaf:
            child.children.extend(sibling.children)
        else:
            # Move values for leaf nodes
            child.values.extend(sibling.values)
            # Update leaf node linkage
            child.next_leaf = sibling.next_leaf
        
        # Remove key and child pointer from parent
        node.keys.pop(index)
        node.children.pop(index+1)
    
    def search(self, key):
        return self._search(self.root, key)
    
    def _search(self, node, key):
        if node.is_leaf:
            for i, k in enumerate(node.keys):
                if k == key:
                    return node.values[i]
            return None
        
        index = self._find_child_index(node, key)
        return self._search(node.children[index], key)
    
    def _find_leaf(self, key):
        """Find the leaf node that should contain the key"""
        node = self.root
        while not node.is_leaf:
            index = self._find_child_index(node, key)
            node = node.children[index]
        return node
    
    def range_query(self, start, end):
        results = []
        node = self._find_leaf(start)
        while node:
            for i, k in enumerate(node.keys):
                if start <= k <= end:
                    results.append((k, node.values[i]))
                elif k > end:
                    return results
            node = node.next_leaf
        return results
    
    def get_all(self):
        """Get all key-value pairs in the tree"""
        results = []
        self._collect_all(self.root, results)
        return results
    
    def _collect_all(self, node, results):
        if node.is_leaf:
            for i in range(len(node.keys)):
                results.append((node.keys[i], node.values[i]))
        else:
            for i in range(len(node.keys)):
                self._collect_all(node.children[i], results)
                # Internal keys don't have values in B+ trees
            if node.children:
                self._collect_all(node.children[-1], results)
    
    def visualize(self, filename='bptree'):
        dot = graphviz.Digraph()
        self._add_nodes(dot, self.root)
        self._add_edges(dot, self.root)
        dot.render(filename, view=True)
    
    def _add_nodes(self, dot, node):
        if node.is_leaf:
            label = "Leaf:\n" + "|".join(map(str, node.keys))
        else:
            label = "Node:\n" + "|".join(map(str, node.keys))
        dot.node(str(id(node)), label=label)
        
        for child in node.children:
            self._add_nodes(dot, child)
            
    def _add_edges(self, dot, node):
        for child in node.children:
            dot.edge(str(id(node)), str(id(child)))
            self._add_edges(dot, child)
        
        if node.is_leaf and node.next_leaf:
            dot.edge(str(id(node)), str(id(node.next_leaf)), style="dashed")
import graphviz

class BPlusTreeNode:
    def __init__(self, is_leaf=False):
        self.keys = []
        self.values = []
        self.children = []
        self.next_leaf = None  # For leaf node linkage
        self.is_leaf = is_leaf

class BPlusTree:
    def __init__(self, order=3):
        self.root = BPlusTreeNode(is_leaf=True)
        self.order = order
        self.min_keys = (order // 2)
        
    def insert(self, key, value):
        if len(self.root.keys) >= (2 * self.order - 1):
            new_root = BPlusTreeNode()
            new_root.children.append(self.root)
            self._split_child(new_root, 0)
            self.root = new_root
        self._insert_non_full(self.root, key, value)
        
    def _insert_non_full(self, node, key, value):
        if node.is_leaf:
            self._insert_into_leaf(node, key, value)
        else:
            index = self._find_child_index(node, key)
            if len(node.children[index].keys) == (2 * self.order - 1):
                self._split_child(node, index)
                if key > node.keys[index]:
                    index += 1
            self._insert_non_full(node.children[index], key, value)
    
    def _insert_into_leaf(self, node, key, value):
        """Insert key-value pair into leaf node in sorted order"""
        index = 0
        while index < len(node.keys) and key > node.keys[index]:
            index += 1
            
        node.keys.insert(index, key)
        node.values.insert(index, value)
    
    def _find_child_index(self, node, key):
        """Find the index of the child node that should contain the key"""
        index = 0
        while index < len(node.keys) and key >= node.keys[index]:
            index += 1
        return index
    
    def _split_child(self, parent, index):
        child = parent.children[index]
        new_node = BPlusTreeNode(is_leaf=child.is_leaf)
        
        mid = len(child.keys) // 2
        split_key = child.keys[mid]
        
        # Handle leaf node split
        if child.is_leaf:
            new_node.keys = child.keys[mid:]
            new_node.values = child.values[mid:]
            child.keys = child.keys[:mid]
            child.values = child.values[:mid]
            new_node.next_leaf = child.next_leaf
            child.next_leaf = new_node
        else:
            new_node.keys = child.keys[mid+1:]
            new_node.children = child.children[mid+1:]
            child.keys = child.keys[:mid]
            child.children = child.children[:mid+1]
        
        parent.keys.insert(index, split_key)
        parent.children.insert(index+1, new_node)
    
    def delete(self, key):
        if not self.root.keys:
            return False
        
        result = self._delete(self.root, key)
        
        # If root is empty and has children, make first child the new root
        if not self.root.keys and self.root.children:
            self.root = self.root.children[0]
            
        return result
            
    def _delete(self, node, key):
        if node.is_leaf:
            if key in node.keys:
                index = node.keys.index(key)
                node.keys.pop(index)
                node.values.pop(index)
                return True
            return False
        
        # Find the index where the key might be
        index = self._find_child_index(node, key)
        
        # If key is in this node
        if index < len(node.keys) and node.keys[index] == key:
            return self._delete_internal(node, key, index)
        else:
            # If the child has less than t keys, fill it
            if len(node.children[index].keys) <= self.min_keys:
                self._fill_child(node, index)
            
            # Recalculate index if child changed
            if index >= len(node.children):
                return self._delete(node.children[index-1], key)
            else:
                return self._delete(node.children[index], key)
    
    def _delete_internal(self, node, key, index):
        # Case 1: If the key is in internal node and its left child has at least t keys
        if len(node.children[index].keys) > self.min_keys:
            # Replace with predecessor
            predecessor = self._get_predecessor(node.children[index])
            node.keys[index] = predecessor
            return self._delete(node.children[index], predecessor)
            
        # Case 2: If right child has at least t keys
        elif len(node.children[index+1].keys) > self.min_keys:
            # Replace with successor
            successor = self._get_successor(node.children[index+1])
            node.keys[index] = successor
            return self._delete(node.children[index+1], successor)
            
        # Case 3: Both children have only t-1 keys, merge them
        else:
            self._merge(node, index)
            return self._delete(node.children[index], key)
    
    def _get_predecessor(self, node):
        """Get rightmost key from the subtree rooted at node"""
        current = node
        while not current.is_leaf:
            current = current.children[-1]
        return current.keys[-1]
    
    def _get_successor(self, node):
        """Get leftmost key from the subtree rooted at node"""
        current = node
        while not current.is_leaf:
            current = current.children[0]
        return current.keys[0]
    
    def _fill_child(self, node, index):
        # If previous child has extra keys
        if index > 0 and len(node.children[index-1].keys) > self.min_keys:
            self._borrow_from_prev(node, index)
        # If next child has extra keys
        elif index < len(node.children)-1 and len(node.children[index+1].keys) > self.min_keys:
            self._borrow_from_next(node, index)
        else:
            # Merge with sibling
            if index < len(node.children)-1:
                self._merge(node, index)
            else:
                self._merge(node, index-1)
    
    def _borrow_from_prev(self, node, index):
        child = node.children[index]
        sibling = node.children[index-1]
        
        # Shift all keys in child right by 1
        child.keys.insert(0, node.keys[index-1])
        
        # Move last key of sibling to parent
        node.keys[index-1] = sibling.keys.pop()
        
        # Handle children if not leaf
        if not child.is_leaf:
            child.children.insert(0, sibling.children.pop())
        else:
            # Move corresponding value for leaf node
            child.values.insert(0, sibling.values.pop())
    
    def _borrow_from_next(self, node, index):
        child = node.children[index]
        sibling = node.children[index+1]
        
        # Move parent key to child
        child.keys.append(node.keys[index])
        
        # Move first key of sibling to parent
        node.keys[index] = sibling.keys.pop(0)
        
        # Handle children if not leaf
        if not sibling.is_leaf:
            child.children.append(sibling.children.pop(0))
        else:
            # Move corresponding value for leaf node
            child.values.append(sibling.values.pop(0))
    
    def _merge(self, node, index):
        child = node.children[index]
        sibling = node.children[index+1]
        
        # Get the key from parent and put in child
        if not child.is_leaf:
            child.keys.append(node.keys[index])
        
        # Add all keys from sibling to child
        child.keys.extend(sibling.keys)
        
        # If not leaf, move children too
        if not child.is_leaf:
            child.children.extend(sibling.children)
        else:
            # Move values for leaf nodes
            child.values.extend(sibling.values)
            # Update leaf node linkage
            child.next_leaf = sibling.next_leaf
        
        # Remove key and child pointer from parent
        node.keys.pop(index)
        node.children.pop(index+1)
    
    def search(self, key):
        return self._search(self.root, key)
    
    def _search(self, node, key):
        if node.is_leaf:
            for i, k in enumerate(node.keys):
                if k == key:
                    return node.values[i]
            return None
        
        index = self._find_child_index(node, key)
        return self._search(node.children[index], key)
    
    def _find_leaf(self, key):
        """Find the leaf node that should contain the key"""
        node = self.root
        while not node.is_leaf:
            index = self._find_child_index(node, key)
            node = node.children[index]
        return node
    
    def range_query(self, start, end):
        results = []
        node = self._find_leaf(start)
        while node:
            for i, k in enumerate(node.keys):
                if start <= k <= end:
                    results.append((k, node.values[i]))
                elif k > end:
                    return results
            node = node.next_leaf
        return results
    
    def get_all(self):
        """Get all key-value pairs in the tree"""
        results = []
        self._collect_all(self.root, results)
        return results
    
    def _collect_all(self, node, results):
        if node.is_leaf:
            for i in range(len(node.keys)):
                results.append((node.keys[i], node.values[i]))
        else:
            for i in range(len(node.keys)):
                self._collect_all(node.children[i], results)
                # Internal keys don't have values in B+ trees
            if node.children:
                self._collect_all(node.children[-1], results)
    
    def visualize(self, filename='bptree'):
        dot = graphviz.Digraph()
        self._add_nodes(dot, self.root)
        self._add_edges(dot, self.root)
        dot.render(filename, view=True)
    
    def _add_nodes(self, dot, node):
        if node.is_leaf:
            label = "Leaf:\n" + "|".join(map(str, node.keys))
        else:
            label = "Node:\n" + "|".join(map(str, node.keys))
        dot.node(str(id(node)), label=label)
        
        for child in node.children:
            self._add_nodes(dot, child)
            
    def _add_edges(self, dot, node):
        for child in node.children:
            dot.edge(str(id(node)), str(id(child)))
            self._add_edges(dot, child)
        
        if node.is_leaf and node.next_leaf:
            dot.edge(str(id(node)), str(id(node.next_leaf)), style="dashed")
