import time
import random
from memory_profiler import profile

class PerformanceAnalyzer:
    @profile
    def benchmark(self, structure, dataset, ops=['insert', 'search', 'delete']):
        results = {}
        data_copy = dataset.copy()
        
        # Insertion test
        if 'insert' in ops:
            start = time.time()
            for k, v in data_copy:
                structure.insert(k, v)
            results['insert'] = time.time() - start
        
        # Search test
        if 'search' in ops:
            start = time.time()
            for k, _ in data_copy:
                structure.search(k)
            results['search'] = time.time() - start
        
        # Deletion test
        if 'delete' in ops:
            start = time.time()
            for k, _ in data_copy:
                structure.delete(k)
            results['delete'] = time.time() - start
        
        return results
        
    def generate_dataset(self, size, max_value=10000):
        """Generate a dataset of key-value pairs"""
        return [(random.randint(1, max_value), f"value_{i}") 
                for i in range(size)]
                
    def compare_structures(self, sizes=[100, 1000, 10000]):
        """Compare B+ Tree with BruteForce across different dataset sizes"""
        from database.bplustree import BPlusTree
        from database.bruteforce import BruteForceDB
        
        results = {}
        
        for size in sizes:
            dataset = self.generate_dataset(size)
            
            # Test B+ Tree
            bptree = BPlusTree()
            bptree_results = self.benchmark(bptree, dataset)
            
            # Test BruteForce
            bruteforce = BruteForceDB()
            bruteforce_results = self.benchmark(bruteforce, dataset)
            
            results[size] = {
                'BPlusTree': bptree_results,
                'BruteForce': bruteforce_results
            }
            
        return results
