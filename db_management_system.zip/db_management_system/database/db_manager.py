from database.table import CollageMemberTable, VehicleTable, VisitorTable
import pickle

class Database:
    def __init__(self):
        self.tables = {
            'CollageMember': CollageMemberTable(),
            'Vehicle': VehicleTable(),
            'Visitor': VisitorTable()
        }

    def save(self, filename='campus_db.pkl'):
        with open(filename, 'wb') as f:
            pickle.dump({
                'tables': self.tables,
                'last_ids': {name: table.last_id for name, table in self.tables.items()}
            }, f)

    def load(self, filename='campus_db.pkl'):
        with open(filename, 'rb') as f:
            data = pickle.load(f)
            self.tables = data['tables']
            for name, last_id in data['last_ids'].items():
                self.tables[name].last_id = last_id
